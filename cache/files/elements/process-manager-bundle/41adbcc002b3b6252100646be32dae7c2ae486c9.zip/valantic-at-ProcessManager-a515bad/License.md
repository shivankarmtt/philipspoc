# License
Copyright (C) valantic CX Austria GmbH (valantic.at)

This software is available under the Pimcore Open Core License (POCL).
The full text of the license can be found at:
https://github.com/pimcore/pimcore/blob/12.x/LICENSE.md

By using this software, you accept all terms and conditions of the POCL.