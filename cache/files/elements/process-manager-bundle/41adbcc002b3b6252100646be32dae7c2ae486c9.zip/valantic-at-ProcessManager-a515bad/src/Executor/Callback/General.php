<?php

/**
 * Created by valantic CX Austria GmbH
 *
 */

namespace Elements\Bundle\ProcessManagerBundle\Executor\Callback;

class General extends AbstractCallback
{
}
