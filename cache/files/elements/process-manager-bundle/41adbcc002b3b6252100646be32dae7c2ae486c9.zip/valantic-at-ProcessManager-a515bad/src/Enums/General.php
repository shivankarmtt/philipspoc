<?php

/**
 * Created by valantic CX Austria GmbH
 *
 */

namespace Elements\Bundle\ProcessManagerBundle\Enums;

class General
{
    final public const EXECUTOR_CLASS_TYPES = ['executorClasses', 'executorActionClasses', 'executorCallbackClasses', 'executorLoggerClasses'];
}
