pimcore.registerNS("pimcore.plugin.processmanager.executor.callback.default");
pimcore.plugin.processmanager.executor.callback.default = Class.create(pimcore.plugin.processmanager.executor.callback.abstractCallback, {
    name: "default"


});