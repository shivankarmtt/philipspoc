<?php

namespace Laminas\Code\Generator;

interface GeneratorInterface
{
    /** @return string */
    public function generate();
}
