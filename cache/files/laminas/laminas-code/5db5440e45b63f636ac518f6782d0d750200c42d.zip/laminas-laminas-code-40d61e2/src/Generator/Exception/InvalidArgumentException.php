<?php

namespace Laminas\Code\Generator\Exception;

use Laminas\Code\Exception;

class InvalidArgumentException extends Exception\InvalidArgumentException implements
    ExceptionInterface
{
}
