<?php

namespace Laminas\Code\Reflection\Exception;

use Laminas\Code\Exception;

class RuntimeException extends Exception\RuntimeException implements
    ExceptionInterface
{
}
