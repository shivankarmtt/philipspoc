- [Current Admins](#current-admins)
- [Admin Responsibilities](#admin-responsibilities)

## Current Admins

| Admin            | GitHub ID                               | Affiliation |
| ---------------- | --------------------------------------- | ----------- |
| Charlotte Henkle | [CEHENKLE](https://github.com/CEHENKLE) | Amazon      |
| Henri Yandell    | [hyandell](https://github.com/hyandell) | Amazon      |


## Admin Responsibilities

[This document](https://github.com/opensearch-project/.github/blob/main/ADMINS.md#admin-responsibilities) explains what admins do in this repo, and how they should be doing it.