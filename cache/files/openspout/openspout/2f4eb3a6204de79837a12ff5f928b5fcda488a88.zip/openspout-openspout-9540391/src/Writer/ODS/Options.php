<?php

declare(strict_types=1);

namespace OpenSpout\Writer\ODS;

use OpenSpout\Writer\Common\AbstractOptions;

final readonly class Options extends AbstractOptions {}
