MercureBundle
=============

Integrates [the Mercure Component](https://github.com/symfony/mercure) in the Symfony full-stack framework.
