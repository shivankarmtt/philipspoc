<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\DefaultSearch\Search;

use Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\DefaultSearchInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Model\SearchIndex\HitData;

interface FetchIdsBySearchServiceInterface
{
    public function fetchAllIds(DefaultSearchInterface $search, string $indexName, bool $sortById = true): array;

    /**
     * @return HitData[]
     */
    public function fetchAllTypesAndIds(
        DefaultSearchInterface $search,
        string $indexName,
        bool $sortById = true
    ): array;
}
