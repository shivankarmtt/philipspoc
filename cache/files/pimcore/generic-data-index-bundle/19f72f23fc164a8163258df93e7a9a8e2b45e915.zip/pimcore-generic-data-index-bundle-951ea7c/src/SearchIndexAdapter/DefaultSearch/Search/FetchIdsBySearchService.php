<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\DefaultSearch\Search;

use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\FieldCategory;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\FieldCategory\SystemField;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\InvalidArgumentException;
use Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\DefaultSearchInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\Sort\FieldSort;
use Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\Sort\FieldSortList;
use Pimcore\Bundle\GenericDataIndexBundle\Model\SearchIndex\HitData;
use Pimcore\Bundle\GenericDataIndexBundle\Model\SearchIndexAdapter\SearchResultHit;
use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\SearchIndexServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\SearchIndexConfigServiceInterface;

/**
 * @internal
 */
final readonly class FetchIdsBySearchService implements FetchIdsBySearchServiceInterface
{
    public function __construct(
        private SearchIndexConfigServiceInterface $searchIndexConfigService,
        private SearchIndexServiceInterface $searchIndexService,
    ) {
    }

    public function fetchAllIds(DefaultSearchInterface $search, string $indexName, bool $sortById = true): array
    {
        $search = clone $search;
        if ($sortById) {
            $search->setSortList(new FieldSortList([new FieldSort(SystemField::ID->getPath())]));
        }

        if ($search->getSortList()->isEmpty()) {
            throw new InvalidArgumentException('Search must have a sort defined to be able to fetch all ids');
        }

        return $this->doFetchIds($search, $indexName);
    }

    /**
     * @return HitData[]
     */
    public function fetchAllTypesAndIds(
        DefaultSearchInterface $search,
        string $indexName,
        bool $sortById = true
    ): array {
        $search = clone $search;
        if ($sortById) {
            $search->setSortList(new FieldSortList([new FieldSort(SystemField::ID->getPath())]));
        }

        if ($search->getSortList()->isEmpty()) {
            throw new InvalidArgumentException('Search must have a sort defined to be able to fetch all ids');
        }

        return $this->doFetchIdsAndTypes($search, $indexName);
    }

    private function doFetchIds(DefaultSearchInterface $search, string $indexName, ?array $searchAfter = null): array
    {
        $search->setFrom(0);
        $search->setSize($this->getPageSize());
        $search->setSource(false);
        $search->setSearchAfter($searchAfter);
        $searchResult = $this->searchIndexService->search($search, $indexName);
        $ids = $searchResult->getIds();

        $lastHit = $searchResult->getLastHit();
        if ($lastHit && (count($ids) === $this->getPageSize())) {
            return array_merge($ids, $this->doFetchIds($search, $indexName, $lastHit->getSort()));
        }

        return $ids;
    }

    private function doFetchIdsAndTypes(
        DefaultSearchInterface $search,
        string $indexName,
        ?array $searchAfter = null
    ): array {
        $search->setFrom(0);
        $search->setSize($this->getPageSize());
        $search->setSource([SystemField::ELEMENT_TYPE->getPath()]);
        $search->setSearchAfter($searchAfter);
        $searchResult = $this->searchIndexService->search($search, $indexName);
        $hits = $searchResult->getHits();
        $idsAndTypes = array_map(
            static fn (SearchResultHit $item) =>
            new HitData(
                id: $item->getId(),
                elementType: $item->getSource()[FieldCategory::SYSTEM_FIELDS->value][SystemField::ELEMENT_TYPE->value],
                index: $item->getIndex(),
            ),
            $hits
        );
        $lastHit = $searchResult->getLastHit();
        if ($lastHit && (count($hits) === $this->getPageSize())) {
            return array_merge($idsAndTypes, $this->doFetchIdsAndTypes($search, $indexName, $lastHit->getSort()));
        }

        return $idsAndTypes;
    }

    private function getPageSize(): int
    {
        $maxResultWindow = $this->searchIndexConfigService->getIndexSettings()['max_result_window'];

        return min($maxResultWindow, 10000);
    }
}
