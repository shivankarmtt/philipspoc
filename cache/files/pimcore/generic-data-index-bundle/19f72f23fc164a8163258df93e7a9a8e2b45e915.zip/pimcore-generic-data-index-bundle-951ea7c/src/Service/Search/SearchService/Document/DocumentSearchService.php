<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\Search\SearchService\Document;

use Exception;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\Permission\PermissionTypes;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\Permission\UserPermissionTypes;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\DocumentSearchException;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Document\DocumentSearchInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Document\SearchResult\DocumentSearchResult;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Document\SearchResult\DocumentSearchResultItem;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Modifier\Filter\Basic\IdFilter;
use Pimcore\Bundle\GenericDataIndexBundle\Permission\Workspace\DocumentWorkspace;
use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\Search\Pagination\PaginationInfoServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\Search\SearchService\SearchProviderInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\ElementTypeAdapter\DocumentTypeAdapter;
use Pimcore\Bundle\StaticResolverBundle\Lib\Cache\RuntimeCacheResolverInterface;
use Pimcore\Model\User;

/**
 * @internal
 */
final readonly class DocumentSearchService implements DocumentSearchServiceInterface
{
    public function __construct(
        private DocumentTypeAdapter $documentTypeAdapter,
        private PaginationInfoServiceInterface $paginationInfoService,
        private RuntimeCacheResolverInterface $runtimeCacheResolver,
        private SearchHelper $searchHelper,
        private SearchProviderInterface $searchProvider
    ) {
    }

    public function search(
        DocumentSearchInterface $documentSearch,
        PermissionTypes $permissionType = PermissionTypes::LIST
    ): DocumentSearchResult {
        $search = $this->searchHelper->addSearchRestrictions(
            search: $documentSearch,
            userPermission: UserPermissionTypes::DOCUMENTS->value,
            workspaceType: DocumentWorkspace::WORKSPACE_TYPE,
            permissionType: $permissionType
        );

        $searchResult = $this->searchHelper->performSearch(
            search: $search,
            indexName: $this->documentTypeAdapter->getAliasIndexName()
        );

        $childrenCounts = $this->searchHelper->getChildrenCounts(
            searchResult: $searchResult,
            indexName: $this->documentTypeAdapter->getAliasIndexName(),
            search: $this->searchProvider->createDocumentSearch()
        );

        try {
            return new DocumentSearchResult(
                items: $this->searchHelper->hydrateSearchResultHits(
                    $searchResult,
                    $childrenCounts,
                    $search->getUser()
                ),
                pagination: $this->paginationInfoService->getPaginationInfoFromSearchResult(
                    searchResult: $searchResult,
                    page: $search->getPage(),
                    pageSize: $search->getPageSize()
                ),
                aggregations:  $searchResult->getAggregations(),
            );
        } catch (Exception $e) {
            throw new DocumentSearchException($e->getMessage());
        }
    }

    /**
     * @throws DocumentSearchException
     */
    public function byId(
        int $id,
        ?User $user = null,
        bool $forceReload = false
    ): ?DocumentSearchResultItem {
        $cacheKey = SearchHelper::DOCUMENT_SEARCH . '_' . $id;

        if ($forceReload) {
            $searchResult = $this->searchDocumentById($id, $user);
            $this->runtimeCacheResolver->save($searchResult, $cacheKey);

            return $searchResult;
        }

        try {
            $searchResult = $this->runtimeCacheResolver->load($cacheKey);
            if ($searchResult === null) {
                $searchResult = $this->searchDocumentById($id, $user);
            }
        } catch (Exception) {
            $searchResult = $this->searchDocumentById($id, $user);
        }

        return $searchResult;
    }

    /**
     * @throws DocumentSearchException
     */
    private function searchDocumentById(int $id, ?User $user = null): ?DocumentSearchResultItem
    {
        $documentSearch = $this->searchProvider->createDocumentSearch();
        $documentSearch->setPageSize(1);
        $documentSearch->addModifier(new IdFilter($id));

        if ($user) {
            $documentSearch->setUser($user);
        }

        return $this->search($documentSearch, PermissionTypes::VIEW)->getItems()[0] ?? null;
    }
}
