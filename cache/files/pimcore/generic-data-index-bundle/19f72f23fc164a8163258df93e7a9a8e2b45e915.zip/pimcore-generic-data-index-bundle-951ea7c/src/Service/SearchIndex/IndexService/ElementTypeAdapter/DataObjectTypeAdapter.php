<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\ElementTypeAdapter;

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use Exception;
use InvalidArgumentException;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\ElementType;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexName;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexQueueOperation;
use Pimcore\Bundle\GenericDataIndexBundle\Event\DataObject\UpdateFolderIndexDataEvent;
use Pimcore\Bundle\GenericDataIndexBundle\Event\DataObject\UpdateIndexDataEvent;
use Pimcore\Bundle\GenericDataIndexBundle\Event\UpdateIndexDataEventInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\Serializer\Normalizer\DataObjectNormalizer;
use Pimcore\Model\DataObject\AbstractObject;
use Pimcore\Model\DataObject\ClassDefinition;
use Pimcore\Model\DataObject\Concrete;
use Pimcore\Model\DataObject\Folder;
use Pimcore\Model\Element\ElementInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

/**
 * @internal
 */
final class DataObjectTypeAdapter extends AbstractElementTypeAdapter
{
    public function __construct(
        private readonly DataObjectNormalizer $normalizer,
        private readonly Connection $dbConnection,
    ) {
    }

    public function supports(ElementInterface $element): bool
    {
        return $element instanceof AbstractObject;
    }

    /**
     * @throws Exception
     */
    public function getIndexNameShortByElement(ElementInterface $element): string
    {
        $classDefinition = null;
        if ($element instanceof Concrete) {
            $classDefinition = $element->getClass();
        }

        return $this->getIndexNameShort($classDefinition);
    }

    public function getIndexNameShort(mixed $context): string
    {
        return match (true) {
            $context instanceof ClassDefinition => $context->getName(),
            $context === IndexName::DATA_OBJECT->value => $context,
            default => IndexName::DATA_OBJECT_FOLDER->value,
        };
    }

    public function getIndexNameByClassDefinition(ClassDefinition $classDefinition): string
    {
        return $this->searchIndexConfigService->getIndexName($classDefinition->getName(), true);
    }

    public function getElementType(): string
    {
        return ElementType::DATA_OBJECT->value;
    }

    /**
     * @param AbstractObject $element
     */
    public function childrenPathRewriteNeeded(ElementInterface $element): bool
    {
        return $element->hasChildren(includingUnpublished: true);
    }

    public function getNormalizer(): NormalizerInterface
    {
        return $this->normalizer;
    }

    public function getRelatedItemsOnUpdateQuery(
        ElementInterface $element,
        string $operation,
        int $operationTime,
        bool $includeElement = false
    ): ?QueryBuilder {
        if (!$element instanceof AbstractObject) {
            return null;
        }

        if (
            ($operation === IndexQueueOperation::DELETE->value) ||
            !$element instanceof Concrete ||
            !$element->getClass()->getAllowInherit()
        ) {
            return $this->getElementQueryBuilder($element, $operation, $operationTime, $includeElement);
        }

        if ($operation !== IndexQueueOperation::UPDATE->value) {
            return null;
        }

        $selects = [
            'id',
            "'" . ElementType::DATA_OBJECT->value . "'",
            'className',
            "'$operation'",
            "'$operationTime'",
            '0',
        ];

        $select = $this->dbConnection->createQueryBuilder()
            ->addSelect(...$selects)
            ->from('objects')
            ->where('type = :objectType')
            ->where('classId = :classId')
            ->andWhere('path LIKE :path')
            ->setParameters([
                'classId' => $element->getClassId(),
                'path' => $element->getRealFullPath() . '/%',
                'objectType' => 'object',
            ]);

        if ($includeElement) {
            $select
                ->orWhere('id = :id')
                ->setParameter('id', $element->getId());
        }

        return $select;
    }

    public function getUpdateIndexDataEvent(
        ElementInterface $element,
        array $customFields
    ): UpdateIndexDataEventInterface {
        if ($element instanceof Folder) {
            return new UpdateFolderIndexDataEvent($element, $customFields);
        }
        if ($element instanceof Concrete) {
            return new UpdateIndexDataEvent($element, $customFields);
        }

        throw new InvalidArgumentException('Element must be instance of ' . AbstractObject::class);
    }

    private function getElementQueryBuilder(
        AbstractObject $element,
        string $operation,
        int $operationTime,
        bool $includeElement = false
    ): ?QueryBuilder {
        if (!$includeElement) {
            return null;
        }

        $queryBuilder = $this->dbConnection->createQueryBuilder()
            ->addSelect(...$this->getSelectParameters($element, $operation, $operationTime))
            ->setMaxResults(1);

        if ($operation === IndexQueueOperation::DELETE->value) {
            return $queryBuilder->from('DUAL');
        }

        return $queryBuilder
            ->from('objects')
            ->where('id = :id')
            ->setParameter('id', $element->getId());
    }

    private function getSelectParameters(
        AbstractObject $element,
        string $operation,
        int $operationTime
    ): array {
        return [
            (string)$element->getId(),
            "'" . ElementType::DATA_OBJECT->value . "'",
            $this->getIndexName($element, $operation),
            "'$operation'",
            "'$operationTime'",
            '0',
        ];
    }

    private function getIndexName(AbstractObject $element, string $operation): string
    {
        if ($element instanceof Concrete) {
            return $operation === IndexQueueOperation::DELETE->value
                ? "'{$element->getClassName()}'"
                : 'className';
        }

        return "'" . IndexName::DATA_OBJECT_FOLDER->value . "'";
    }
}
