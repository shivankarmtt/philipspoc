<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\Permission;

use Pimcore\Model\DataObject;
use Pimcore\Model\Element\ElementInterface;
use Pimcore\Model\User;

interface ElementPermissionServiceInterface
{
    public function isAllowed(
        string $permission,
        ElementInterface $element,
        User $user,
        ?string $specialPermission = null
    ): bool;

    public function getSpecialPermissions(DataObject $dataObject, User $user, string $permission): array;
}
