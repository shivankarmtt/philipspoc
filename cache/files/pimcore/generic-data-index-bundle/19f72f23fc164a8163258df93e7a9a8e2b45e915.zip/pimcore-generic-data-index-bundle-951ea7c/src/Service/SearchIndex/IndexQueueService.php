<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex;

use Exception;
use Pimcore\Bundle\GenericDataIndexBundle\Entity\IndexQueue;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\ElementType;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexName;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\SearchIndex\IndexQueueOperation;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\HandleIndexQueueEntriesException;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\IndexDataException;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\InvalidArgumentException;
use Pimcore\Bundle\GenericDataIndexBundle\Message\EnqueueRelatedIdsMessage;
use Pimcore\Bundle\GenericDataIndexBundle\Repository\IndexQueueRepository;
use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\BulkOperationServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\PathServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\ElementServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexQueue\EnqueueServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexService\IndexServiceInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Traits\LoggerAwareTrait;
use Pimcore\Model\Asset;
use Pimcore\Model\Element\ElementInterface;
use Symfony\Component\Messenger\MessageBusInterface;

/**
 * @internal
 */
final class IndexQueueService implements IndexQueueServiceInterface
{
    use LoggerAwareTrait;

    public function __construct(
        private readonly IndexServiceInterface $indexService,
        private readonly PathServiceInterface $pathService,
        private readonly BulkOperationServiceInterface $bulkOperationService,
        private readonly IndexQueueRepository $indexQueueRepository,
        private readonly EnqueueServiceInterface $enqueueService,
        private readonly ElementServiceInterface $elementService,
        private readonly SearchIndexConfigServiceInterface $searchIndexConfigService,
        private readonly MessageBusInterface $messageBus
    ) {
    }

    public function updateIndexQueue(
        ElementInterface $element,
        string $operation,
        bool $processSynchronously = false,
        bool $enqueueRelatedItems = true,
        bool $enqueueRelatedItemsAsync = false
    ): IndexQueueService {
        try {
            $this->checkOperationValid($operation);

            if ($processSynchronously) {
                $this->doHandleIndexData($element, $operation);
            }

            if ($enqueueRelatedItems || $processSynchronously === false) {
                if ($enqueueRelatedItemsAsync) {
                    $this->dispatchEnqueueRelatedIdsMessage($element, $operation, !$processSynchronously);
                } else {
                    $this->handleQueueByOperation($element, $operation, $processSynchronously);
                }
            }

            $this->pathService->rewriteChildrenIndexPaths($element);
        } catch (Exception $e) {
            $this->logger->error(
                sprintf(
                    'Update indexQueue in database-table %s failed! Error: %s',
                    IndexQueue::TABLE,
                    $e->getMessage()
                )
            );
        }

        return $this;
    }

    /**
     * @param IndexQueue[] $entries
     */
    public function handleIndexQueueEntries(array $entries): void
    {
        try {

            foreach ($entries as $entry) {
                $this->logger->debug(
                    sprintf(
                        '%s updating index for element %s and type %s',
                        IndexQueue::TABLE,
                        $entry->getElementId(),
                        $entry->getElementType()
                    ));
                $this->handleEntryByOperation($entry->getOperation(), $entry);
            }

            $this->bulkOperationService->commit();
            $this->indexQueueRepository->deleteQueueEntries($entries);

        } catch (Exception $e) {
            throw new HandleIndexQueueEntriesException('handleIndexQueueEntry failed! Error: ' . $e->getMessage(), 0, $e);
        }
    }

    public function commit(?string $refreshIndex = null): IndexQueueService
    {
        $this->bulkOperationService->commit($refreshIndex);

        return $this;
    }

    /**
     * @throws IndexDataException
     */
    private function doHandleIndexData(ElementInterface $element, string $operation): void
    {
        switch ($operation) {
            case IndexQueueOperation::UPDATE->value:
                $this->indexService->updateIndexData($element);

                break;
            case IndexQueueOperation::DELETE->value:
                $this->indexService->deleteFromIndex($element);

                break;
            default:
                throw new InvalidArgumentException(sprintf('Operation %s not valid', $operation));
        }
    }

    /**
     * @throws Exception
     */
    private function handleQueueByOperation(
        ElementInterface $element,
        string $operation,
        bool $processSynchronously
    ): void {
        $this->enqueueService->enqueueRelatedItems(
            element: $element,
            includeElement: !$processSynchronously,
            operation: $operation
        );

        if (($operation === IndexQueueOperation::UPDATE->value) && $element instanceof Asset) {
            $this->enqueueService->enqueueDependentItems(
                element: $element,
                operation: IndexQueueOperation::UPDATE
            );
        }

        if ($operation === IndexQueueOperation::DELETE->value) {
            $this->enqueueService->enqueueDependentItems(
                element: $element,
                operation: IndexQueueOperation::UPDATE
            );
        }
    }

    private function handleEntryByOperation(string $operation, IndexQueue $entry): void
    {
        if ($operation === IndexQueueOperation::DELETE->value) {
            $isClass = false;
            if ($entry->getElementType() === ElementType::DATA_OBJECT->value &&
                $entry->getElementIndexName() !== IndexName::DATA_OBJECT_FOLDER->value
            ) {
                $isClass = true;
            }

            $this->indexService->deleteFromSpecificIndex(
                $this->searchIndexConfigService->getIndexName(
                    $entry->getElementIndexName(),
                    $isClass
                ),
                $entry->getElementId()
            );

            return;
        }

        $element = $this->elementService->getElementByType($entry->getElementId(), $entry->getElementType());
        if ($element) {
            $this->doHandleIndexData($element, $entry->getOperation());
        }
    }

    /**
     * @throws IndexDataException
     */
    private function checkOperationValid(string $operation): void
    {
        if (!in_array($operation, [
            IndexQueueOperation::UPDATE->value,
            IndexQueueOperation::DELETE->value,
        ], true)) {
            throw new IndexDataException(sprintf('Operation %s not valid', $operation));
        }
    }

    private function dispatchEnqueueRelatedIdsMessage(
        ElementInterface $element,
        string $operation,
        bool $addParentElement
    ): void {
        $this->messageBus->dispatch(
            new EnqueueRelatedIdsMessage(
                $element->getId(),
                $this->elementService->getElementType($element),
                $operation,
                $addParentElement
            )
        );
    }
}
