<?php
declare(strict_types=1);

namespace Pimcore\Bundle\StaticResolverBundle\Tests\Unit\Proxy\TestData;

interface TestUserInterface
{
    public function getFirstName(): string;
}
