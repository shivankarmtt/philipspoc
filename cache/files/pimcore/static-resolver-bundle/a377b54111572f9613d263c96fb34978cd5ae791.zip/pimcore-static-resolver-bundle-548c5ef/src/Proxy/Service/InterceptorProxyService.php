<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StaticResolverBundle\Proxy\Service;

use Pimcore\Bundle\StaticResolverBundle\Proxy\Factory\Events\InterceptorProxyEventFactoryInterface;
use Pimcore\Bundle\StaticResolverBundle\Proxy\Factory\SmartReference\SmartReferenceFactoryInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * @internal
 *
 * @deprecated Will be removed in 3.0
 */
final class InterceptorProxyService implements InterceptorProxyServiceInterface
{
    public function __construct(
        private readonly EventDispatcherInterface $eventDispatcher,
        private readonly SmartReferenceFactoryInterface $smartReferenceFactory,
        private readonly InterceptorProxyEventFactoryInterface $proxyEventFactory
    ) {
    }

    public function getEventDispatcherProxy(
        object $instance,
        array $preInterceptors = [],
        array $postInterceptors = [],
        ?string $customEventName = null
    ): object {
        $proxy = $this->smartReferenceFactory->createProxy($instance);
        $this->addPreInterceptors($preInterceptors, $proxy, $customEventName);
        $this->addPostInterceptors($postInterceptors, $proxy, $customEventName);

        return $proxy;
    }

    private function addPreInterceptors(array $preInterceptors, object $proxy, ?string $customEventName): void
    {
        foreach ($preInterceptors as $method) {
            $proxy->setMethodPrefixInterceptor(
                $method,
                function ($proxy, $instance, $method, $params, & $returnEarly) use ($customEventName): mixed {
                    $event = $this->proxyEventFactory->createInterceptorPreEvent(
                        $instance,
                        compact('method', 'params', 'returnEarly')
                    );
                    $this->eventDispatcher->dispatch($event, $this->getEventName($instance, $method, 'pre'));
                    if ($customEventName) {
                        $this->eventDispatcher->dispatch($event, strtolower($customEventName) . '.pre');
                    }

                    if ($event->hasResponse()) {
                        $returnEarly = true;

                        return $event->getResponse();
                    }

                    return null;
                }
            );
        }
    }

    private function addPostInterceptors(array $postInterceptors, object $proxy, ?string $customEventName): void
    {
        foreach ($postInterceptors as $method) {
            $proxy->setMethodSuffixInterceptor(
                $method,
                function (
                    $proxy,
                    $instance,
                    $method,
                    $params,
                    $returnValue
                ) use ($customEventName): mixed {
                    $event = $this->proxyEventFactory->createInterceptorPostEvent(
                        $instance,
                        compact('method', 'params', 'returnValue')
                    );
                    $this->eventDispatcher->dispatch($event, $this->getEventName($instance, $method, 'post'));
                    if ($customEventName) {
                        $this->eventDispatcher->dispatch($event, strtolower($customEventName) . '.post');
                    }

                    return null;
                }
            );
        }
    }

    private function getEventName(object $instance, mixed $method, string $prefix): string
    {
        return strtolower(
            str_replace('\\', '.', get_class($instance)) . '.' . $method . '.' . $prefix
        );
    }
}
