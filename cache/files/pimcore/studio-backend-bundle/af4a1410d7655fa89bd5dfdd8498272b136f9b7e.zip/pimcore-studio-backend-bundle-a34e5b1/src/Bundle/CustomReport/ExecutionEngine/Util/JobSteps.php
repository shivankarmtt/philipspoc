<?php

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Bundle\CustomReport\ExecutionEngine\Util;

enum JobSteps: string
{
    case CUSTOM_REPORT_CSV_COLLECTION = 'studio_ee_job_step_custom_report_csv_collection';
}
