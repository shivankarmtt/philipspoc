<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Class\Event;

use Pimcore\Bundle\StudioBackendBundle\Class\Schema\LayoutCompact;
use Pimcore\Bundle\StudioBackendBundle\Event\AbstractPreResponseEvent;

final class CompactLayoutCollectionEvent extends AbstractPreResponseEvent
{
    public const string EVENT_NAME = 'pre_response.all_layouts.collection';

    public function __construct(private readonly LayoutCompact $layout)
    {
        parent::__construct($this->layout);
    }

    public function getLayout(): LayoutCompact
    {
        return $this->layout;
    }
}
