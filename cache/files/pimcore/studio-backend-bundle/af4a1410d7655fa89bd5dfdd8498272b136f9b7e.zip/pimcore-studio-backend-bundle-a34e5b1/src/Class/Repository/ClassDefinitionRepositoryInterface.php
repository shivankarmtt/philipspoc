<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Class\Repository;

use Pimcore\Bundle\StudioBackendBundle\Class\MappedParameter\CreateClassDefinitionParameters;
use Pimcore\Bundle\StudioBackendBundle\Class\MappedParameter\UpdateParameters;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ConflictException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ElementExistsException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ElementSavingFailedException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidArgumentException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\NotFoundException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\NotWriteableException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\UserNotFoundException;
use Pimcore\Model\DataObject\ClassDefinition;

/**
 * @internal
 */
interface ClassDefinitionRepositoryInterface
{
    /**
     * @return ClassDefinition[]
     */
    public function getClassDefinitions(): array;

    /**
     * @throws NotFoundException
     */
    public function getClassDefinitionById(string $id): ClassDefinition;

    /**
     * @throws NotFoundException
     */
    public function getClassDefinition(string $dataObjectClass): ClassDefinition;

    /**
     * @throws NotFoundException|NotWriteableException
     */
    public function delete(ClassDefinition $classDefinition): void;

    /**
     * @throws ElementExistsException|ElementSavingFailedException|UserNotFoundException|NotWriteableException
     */
    public function create(CreateClassDefinitionParameters $parameters): ClassDefinition;

    /**
     * @throws ConflictException|InvalidArgumentException
     * @throws ElementSavingFailedException|NotWriteableException|UserNotFoundException
     */
    public function update(ClassDefinition $classDefinition, UpdateParameters $updateParameters): ClassDefinition;

    public function exportAsJson(ClassDefinition $classDefinition): string;

    /**
     * @throws InvalidArgumentException|ElementSavingFailedException|NotWriteableException
     */
    public function importFromJson(ClassDefinition $classDefinition, string $json): ClassDefinition;
}
