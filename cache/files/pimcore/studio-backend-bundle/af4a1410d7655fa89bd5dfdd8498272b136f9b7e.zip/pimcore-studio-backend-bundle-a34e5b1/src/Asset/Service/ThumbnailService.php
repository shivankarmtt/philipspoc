<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Asset\Service;

use Exception;
use Pimcore\Bundle\StaticResolverBundle\Lib\ConfigResolverInterface as SystemConfigResolverInterface;
use Pimcore\Bundle\StaticResolverBundle\Models\Asset\Image\Thumbnail\ConfigResolverInterface as ImageConfigResolver;
use Pimcore\Bundle\StaticResolverBundle\Models\Asset\Video\Thumbnail\ConfigResolverInterface as VideoConfigResolver;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\BasicStreamConfigParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\DocumentImageDownloadConfigParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\DynamicConfigurationParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\ImageDownloadConfigParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\StreamCropParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\VideoImageStreamConfigParameter;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidThumbnailConfigurationException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidThumbnailException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ThumbnailResizingFailedException;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\Asset\FormatTypes;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\Asset\MimeTypes;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\Asset\ResizeModes;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\Thumbnails;
use Pimcore\Bundle\StudioBackendBundle\Util\Trait\ConsoleExecutableTrait;
use Pimcore\Model\Asset\Document;
use Pimcore\Model\Asset\Document\ImageThumbnailInterface as DocumentThumbnail;
use Pimcore\Model\Asset\Image;
use Pimcore\Model\Asset\Image\Thumbnail\Config as ImageThumbnailConfig;
use Pimcore\Model\Asset\Image\ThumbnailInterface;
use Pimcore\Model\Asset\Video;
use Pimcore\Model\Asset\Video\ImageThumbnailInterface as VideoImageThumbnail;
use Pimcore\Model\Asset\Video\Thumbnail\Config as VideoThumbnailConfig;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Process\Process;

/**
 * @internal
 */
final readonly class ThumbnailService implements ThumbnailServiceInterface
{
    use ConsoleExecutableTrait;

    public function __construct(
        private ImageConfigResolver $imageConfigResolver,
        private SystemConfigResolverInterface $systemConfigResolver,
        private VideoConfigResolver $videoConfigResolver,
    ) {

    }

    /**
     * @throws InvalidThumbnailException
     */
    public function getImageThumbnailByName(
        Image $image,
        string $thumbnailName,
        ?BasicStreamConfigParameter $parameter = null
    ): ThumbnailInterface {
        try {
            $thumbnail = $image->getThumbnail($thumbnailName);
        } catch (Exception) {
            throw new InvalidThumbnailException($thumbnailName);
        }

        $thumbnailConfig = $thumbnail->getConfig();

        $autoFormatConfigs = $thumbnailConfig->getAutoFormatThumbnailConfigs();
        if ($autoFormatConfigs && $thumbnailConfig->getFormat() === strtoupper(FormatTypes::SOURCE)) {
            $config = current($autoFormatConfigs);
            if ($config !== false) {
                $thumbnailConfig = $config;
            }
        }

        $format = $thumbnailConfig->getFormat();
        if ($parameter !== null) {
            $thumbnailConfig = $this->setThumbnailConfigCropParameter($parameter, $thumbnailConfig);
            $format = $parameter->getMimeType() ?: $format;
        }

        $thumbnailConfig = $this->setThumbnailConfigFormatParameter(
            $format,
            $thumbnailConfig
        );

        return $image->getThumbnail($thumbnailConfig);
    }

    /**
     * @throws ThumbnailResizingFailedException
     */
    public function getThumbnailFromConfiguration(
        Image $image,
        ImageDownloadConfigParameter $parameters
    ): ThumbnailInterface {
        $thumbnailConfig = $this->getImageThumbnailConfig($image->getId(), $parameters);
        $thumbnail = $image->getThumbnail($thumbnailConfig);
        $dpi = $parameters->getDpi();
        if ($dpi && $thumbnailConfig->getFormat() === MimeTypes::JPEG->value) {
            $this->resizeThumbnailFile($thumbnail, $dpi);
        }

        return $thumbnail;
    }

    /**
     * @throws InvalidThumbnailException
     */
    public function getDynamicThumbnail(
        Image $image,
        DynamicConfigurationParameter $parameter
    ): ThumbnailInterface {
        $dynamicConfig = $parameter->getDynamicConfig()['thumbnail'] ?? $parameter->getDynamicConfig();
        $thumbnailConfig = $image->getThumbnail($dynamicConfig)->getConfig();
        if ($thumbnailConfig === null) {
            throw new InvalidThumbnailException('configuration not found');
        }
        $thumbnailConfig = $this->setThumbnailConfigFormatParameter(
            $parameter->getMimeType() ?: $thumbnailConfig->getFormat(),
            $thumbnailConfig
        );
        $thumbnailConfig = $this->setThumbnailConfigCropParameter($parameter, $thumbnailConfig);

        return $image->getThumbnail($thumbnailConfig);
    }

    public function getBinaryResponseFromThumbnail(
        Image\ThumbnailInterface $thumbnail,
        Image $image,
        bool $deleteAfterSend = true
    ): BinaryFileResponse {
        $downloadFilename = preg_replace(
            '/\.' . preg_quote(pathinfo($image->getFilename(), PATHINFO_EXTENSION), '/') . '$/i',
            '.' . $thumbnail->getFileExtension(),
            $image->getFilename()
        );

        clearstatcache();

        $response = new BinaryFileResponse($thumbnail->getLocalFile());
        $response->headers->set('Content-Type', $thumbnail->getMimeType());
        $response->setContentDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, $downloadFilename);
        $response->deleteFileAfterSend($deleteAfterSend);

        return $response;
    }

    /**
     * @throws InvalidThumbnailException
     */
    public function getImagePreviewThumbnail(Image $image): ThumbnailInterface
    {
        $thumbnailConfig = $this->getSystemImageThumbnailConfig();
        if ($thumbnailConfig === null) {
            $thumbnailConfig = $this->getDefaultImageThumbnailConfig();
        }

        return $image->getThumbnail($thumbnailConfig);
    }

    /**
     * @throws InvalidThumbnailException
     */
    public function getAssetImagePreviewThumbnail(Video|Document $asset): DocumentThumbnail|VideoImageThumbnail
    {
        $thumbnailConfig = $this->getSystemImageThumbnailConfig();
        if ($thumbnailConfig === null) {
            $thumbnailConfig = $this->getDefaultImageThumbnailConfig();
        }

        return $asset->getImageThumbnail($thumbnailConfig);
    }

    /**
     * @throws InvalidThumbnailException
     */
    public function getImageThumbnailConfigByName(
        string $thumbnailName,
        ?StreamCropParameter $parameter = null
    ): ImageThumbnailConfig {
        try {
            $config = $this->imageConfigResolver->getByName($thumbnailName);
        } catch (Exception) {
            throw new InvalidThumbnailException($thumbnailName);
        }

        if (!$config instanceof ImageThumbnailConfig) {
            $config = $this->imageConfigResolver->getPreviewConfig();
        }

        if ($parameter === null) {
            return $config;
        }

        return $this->setThumbnailConfigCropParameter($parameter, $config);
    }

    public function getDocumentThumbnailConfig(
        Document $document,
        DocumentImageDownloadConfigParameter $parameters
    ): ImageThumbnailConfig {
        $thumbnailConfig = $this->getImageThumbnailConfig($document->getId(), $parameters);
        if ($parameters->getMimeType() === MimeTypes::SOURCE->value) {
            $thumbnailConfig->setFormat(MimeTypes::JPEG->value);
        }

        return $thumbnailConfig;
    }

    /**
     * @throws InvalidThumbnailException
     */
    public function getDynamicDocumentThumbnail(
        Document $document,
        DynamicConfigurationParameter $parameter
    ): ImageThumbnailConfig {
        $dynamicConfig = $parameter->getDynamicConfig()['thumbnail'] ?? $parameter->getDynamicConfig();
        $thumbnailConfig = $document->getImageThumbnail($dynamicConfig)->getConfig();
        if ($thumbnailConfig === null) {
            throw new InvalidThumbnailException('configuration not found');
        }
        $thumbnailConfig = $this->setThumbnailConfigFormatParameter(
            $parameter->getMimeType() ?: $thumbnailConfig->getFormat(),
            $thumbnailConfig
        );

        return $this->setThumbnailConfigCropParameter($parameter, $thumbnailConfig);
    }

    /**
     * @throws InvalidThumbnailException
     */
    public function getVideoThumbnailConfig(
        string $thumbnailName
    ): VideoThumbnailConfig {
        try {
            $config = $this->videoConfigResolver->getByName($thumbnailName);
        } catch (Exception) {
            throw new InvalidThumbnailException($thumbnailName);
        }

        if (!$config instanceof VideoThumbnailConfig) {
            $config = $this->videoConfigResolver->getPreviewConfig();
        }

        return $config;
    }

    /**
     * @throws InvalidThumbnailConfigurationException
     */
    public function validateCustomVideoThumbnailConfig(
        VideoImageStreamConfigParameter $imageConfig
    ): void {
        if ($imageConfig->getFrame() && (!$imageConfig->getWidth() || !$imageConfig->getHeight())) {
            throw new InvalidThumbnailConfigurationException(
                'Width and height must be set for frame configuration'
            );
        }
        if ($imageConfig->getAspectRatio() && !$imageConfig->getWidth()) {
            throw new InvalidThumbnailConfigurationException(
                'Width must be set for aspect ratio configuration'
            );
        }
    }

    private function getSystemImageThumbnailConfig(): ?ImageThumbnailConfig
    {
        $thumbnailConfig = null;
        $assetConfig = $this->systemConfigResolver->getSystemConfiguration('assets');
        if (isset($assetConfig['preview_thumbnail']) && $assetConfig['preview_thumbnail']) {
            try {
                $thumbnailConfig = $this->imageConfigResolver->getByName($assetConfig['preview_thumbnail']);
            } catch (Exception) {
                throw new InvalidThumbnailException($assetConfig['preview_thumbnail']);
            }
        }

        return $thumbnailConfig;
    }

    private function getImageThumbnailConfig(
        int $assetId,
        ImageDownloadConfigParameter $parameters
    ): ImageThumbnailConfig {
        $thumbnailConfig = new ImageThumbnailConfig();
        $thumbnailConfig->setName('pimcore-download-' . $assetId . '-' . md5(serialize($parameters)));
        $thumbnailConfig = $this->setThumbnailConfigResizeParameters($parameters, $thumbnailConfig);
        $thumbnailConfig = $this->setThumbnailConfigFormatParameter($parameters->getMimeType(), $thumbnailConfig);
        $quality = $parameters->getQuality();

        if ($quality !== null && $quality > 0 && $quality <= 100) {
            $thumbnailConfig->setQuality($quality);
        }

        if ($parameters->getMimeType() === MimeTypes::JPEG->value) {
            $thumbnailConfig->setPreserveMetaData(true);

            if ($quality === null) {
                $thumbnailConfig->setPreserveColor(true);
            }
        }

        if ($parameters->hasCover()) {
            $thumbnailConfig->addItem('cover', $parameters->getCoverTransformation());
        }

        if ($parameters->hasFrame()) {
            $thumbnailConfig->addItem('frame', $parameters->getFrameTransformation());
        }

        if ($parameters->hasContain()) {
            $thumbnailConfig->addItem('contain', $parameters->getContainTransformation());
        }

        return $this->setThumbnailConfigCropParameter($parameters, $thumbnailConfig);
    }

    private function getDefaultImageThumbnailConfig(): ImageThumbnailConfig
    {
        $previewThumbnail = new ImageThumbnailConfig();
        $previewThumbnail->setName(Thumbnails::DEFAULT_STUDIO_THUMBNAIL_ID->value);
        $previewThumbnail->setFormat(MimeTypes::PJPEG->value);
        $previewThumbnail->setQuality(60);
        $previewThumbnail->addItem(
            'contain',
            [
                'width' => 1920,
                'height' => 1920,
                'forceResize' => false,
            ]
        );
        $previewThumbnail->addItem(
            'setBackgroundImage',
            [
                'path' => '/bundles/pimcorestudiobackend/img/tree-preview-transparent-background.png',
                'mode' => 'asTexture',
            ]
        );

        return $previewThumbnail;
    }

    private function setThumbnailConfigResizeParameters(
        ImageDownloadConfigParameter $parameters,
        ImageThumbnailConfig $thumbnailConfig
    ): ImageThumbnailConfig {
        $resizeWidth = $parameters->getWidth();
        $resizeHeight = $parameters->getHeight();

        match ($parameters->getResizeMode()) {
            ResizeModes::SCALE_BY_WIDTH => $thumbnailConfig->addItem(
                ResizeModes::SCALE_BY_WIDTH,
                [
                    'width' => $resizeWidth,
                ]
            ),
            ResizeModes::SCALE_BY_HEIGHT => $thumbnailConfig->addItem(
                ResizeModes::SCALE_BY_HEIGHT,
                [
                    'height' => $resizeHeight,
                ]
            ),
            ResizeModes::RESIZE => $thumbnailConfig->addItem(
                ResizeModes::RESIZE,
                [
                    'width' => $resizeWidth,
                    'height' => $resizeHeight,
                ]
            ),
            default => null
        };

        return $thumbnailConfig;
    }

    private function setThumbnailConfigFormatParameter(
        ?string $mimeType,
        ImageThumbnailConfig $thumbnailConfig
    ): ImageThumbnailConfig {
        if ($mimeType === null) {
            return $thumbnailConfig;
        }

        $mimeType = strtolower($mimeType);
        if ($mimeType === MimeTypes::SOURCE->value || $mimeType === MimeTypes::PRINT->value) {
            $mimeType = MimeTypes::PNG->value;
        }

        $thumbnailConfig->setFormat($mimeType);
        $thumbnailConfig->setRasterizeSVG(true);

        return $thumbnailConfig;
    }

    private function setThumbnailConfigCropParameter(
        StreamCropParameter $parameters,
        ImageThumbnailConfig $thumbnailConfig
    ): ImageThumbnailConfig {
        if (!$parameters->getCropPercent()) {

            return $thumbnailConfig;
        }

        $thumbnailConfig->addItemAt(0, 'cropPercent', [
            'width' => $parameters->getCropWidth(),
            'height' => $parameters->getCropHeight(),
            'y' => $parameters->getCropTop(),
            'x' => $parameters->getCropLeft(),
        ]);

        $thumbnailConfig->generateAutoName();

        return $thumbnailConfig;
    }

    /**
     * @throws ThumbnailResizingFailedException
     */
    private function resizeThumbnailFile(
        ThumbnailInterface $thumbnail,
        int $dpi
    ): void {
        $exiftool = $this->getExecutable('exiftool', 'thumbnail resizing');

        try {
            $process = new Process([
                $exiftool, '-overwrite_original', '-xresolution=' . $dpi,
                '-yresolution=' . $dpi, '-resolutionunit=inches',
                $thumbnail->getLocalFile(),
            ]);
            $process->run();
        } catch (Exception $e) {
            throw new ThumbnailResizingFailedException($e->getMessage());
        }
    }
}
