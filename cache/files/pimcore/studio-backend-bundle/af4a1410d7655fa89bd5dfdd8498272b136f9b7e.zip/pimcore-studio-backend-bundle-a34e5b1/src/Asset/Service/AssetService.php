<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Asset\Service;

use Exception;
use Pimcore\Bundle\StaticResolverBundle\Models\Asset\AssetServiceResolverInterface;
use Pimcore\Bundle\StaticResolverBundle\Models\Element\ServiceResolverInterface;
use Pimcore\Bundle\StudioBackendBundle\Asset\Event\PreResponse\AssetEvent;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Asset;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\Archive;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\AssetFolder;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\Audio;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\Document;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\Image;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\Text;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\Unknown;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\Type\Video;
use Pimcore\Bundle\StudioBackendBundle\DataIndex\Query\AssetQueryInterface;
use Pimcore\Bundle\StudioBackendBundle\DataIndex\Request\ElementParameters;
use Pimcore\Bundle\StudioBackendBundle\DataIndex\SearchIndexFilterInterface;
use Pimcore\Bundle\StudioBackendBundle\DataIndex\Service\AssetSearchServiceInterface;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\DatabaseException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ForbiddenException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidElementTypeException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidFilterServiceTypeException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidFilterTypeException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidQueryTypeException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\NotFoundException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\SearchException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\UserNotFoundException;
use Pimcore\Bundle\StudioBackendBundle\Filter\Service\FilterServiceProviderInterface;
use Pimcore\Bundle\StudioBackendBundle\Response\Collection;
use Pimcore\Bundle\StudioBackendBundle\Security\Service\SecurityServiceInterface;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\ElementPermissions;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\ElementTypes;
use Pimcore\Bundle\StudioBackendBundle\Util\Trait\ElementProviderTrait;
use Pimcore\Bundle\StudioBackendBundle\Util\Trait\UserPermissionTrait;
use Pimcore\Bundle\StudioBackendBundle\Workflow\Service\WorkflowDetailsServiceInterface;
use Pimcore\Model\Asset as AssetModel;
use Pimcore\Model\UserInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * @internal
 */
final readonly class AssetService implements AssetServiceInterface
{
    use ElementProviderTrait;
    use UserPermissionTrait;

    public function __construct(
        private AssetSearchServiceInterface $assetSearchService,
        private AssetServiceResolverInterface $assetServiceResolver,
        private EventDispatcherInterface $eventDispatcher,
        private FilterServiceProviderInterface $filterServiceProvider,
        private SecurityServiceInterface $securityService,
        private ServiceResolverInterface $serviceResolver,
        private WorkflowDetailsServiceInterface $workflowDetailsService,
    ) {
    }

    /**
     * @throws InvalidFilterServiceTypeException|SearchException|InvalidQueryTypeException|InvalidFilterTypeException
     */
    public function getAssets(ElementParameters $parameters): Collection
    {
        /** @var SearchIndexFilterInterface $filterService */
        $filterService = $this->filterServiceProvider->create(SearchIndexFilterInterface::SERVICE_TYPE);

        /** @var AssetQueryInterface $assetQuery */
        $assetQuery = $filterService->applyFilters(
            $parameters,
            ElementTypes::TYPE_ASSET
        );

        $assetQuery->orderByPath('asc');
        $assetQuery->setUser($this->securityService->getCurrentUser());

        $result = $this->assetSearchService->searchAssets($assetQuery);

        $items = $result->getItems();

        foreach ($items as $item) {
            $this->dispatchAssetEvent($item);
        }

        return new Collection($result->getTotalItems(), $items);
    }

    /**
     * @throws SearchException|NotFoundException|UserNotFoundException
     */
    public function getAsset(
        int $id,
        bool $getWorkflowAvailable = true
    ): Asset|Archive|Audio|Document|AssetFolder|Image|Text|Unknown|Video {

        $user = $this->securityService->getCurrentUser();
        $asset = $this->assetSearchService->getAssetById($id, $user);
        if ($getWorkflowAvailable) {
            $asset->setHasWorkflowAvailable($this->workflowDetailsService->hasElementWorkflowsById(
                $id,
                ElementTypes::TYPE_ASSET,
                $user
            ));
        }
        $this->dispatchAssetEvent($asset);

        return $asset;
    }

    /**
     * @throws SearchException|NotFoundException
     */
    public function getAssetForUser(
        int $id,
        UserInterface $user
    ): Asset|Archive|Audio|Document|AssetFolder|Image|Text|Unknown|Video {
        $asset = $this->assetSearchService->getAssetById($id, $user);

        $this->dispatchAssetEvent($asset);

        return $asset;
    }

    /**
     * @throws SearchException|NotFoundException
     */
    public function getAssetFolder(int $id, bool $checkPermissionsForCurrentUser = true): AssetFolder
    {
        $asset = $this->assetSearchService->getAssetById(
            $id,
            $this->getUserForPermissionCheck($this->securityService, $checkPermissionsForCurrentUser)
        );

        if (!$asset instanceof AssetFolder) {
            throw new NotFoundException(ElementTypes::TYPE_FOLDER, $id);
        }

        $this->dispatchAssetEvent($asset);

        return $asset;
    }

    /**
     * @throws SearchException|NotFoundException
     */
    public function getAssetFolderForUser(int $id, UserInterface $user): AssetFolder
    {
        $asset = $this->assetSearchService->getAssetById($id, $user);

        if (!$asset instanceof AssetFolder) {
            throw new NotFoundException(ElementTypes::TYPE_FOLDER, $id);
        }

        $this->dispatchAssetEvent($asset);

        return $asset;
    }

    /**
     * @throws SearchException|NotFoundException
     */
    public function assetFolderExists(int $id, bool $checkPermissionsForCurrentUser = true): bool
    {
        try {
            $this->getAssetFolder($id, $checkPermissionsForCurrentUser);

            return true;
        } catch (NotFoundException) {
            return false;
        }
    }

    /**
     * @throws SearchException|NotFoundException
     */
    public function assetFolderExistsForUser(int $id, UserInterface $user): bool
    {
        try {
            $this->getAssetFolderForUser($id, $user);

            return true;
        } catch (NotFoundException) {
            return false;
        }
    }

    /**
     * @throws ForbiddenException|NotFoundException
     */
    public function getAssetElement(
        UserInterface $user,
        int $assetId,
    ): AssetModel {
        $asset = $this->getElement($this->serviceResolver, ElementTypes::TYPE_ASSET, $assetId);
        $this->securityService->hasElementPermission($asset, $user, ElementPermissions::VIEW_PERMISSION);

        if (!$asset instanceof AssetModel) {
            throw new InvalidElementTypeException($asset->getType());
        }

        return $asset;
    }

    /**
     * @throws ForbiddenException|NotFoundException
     */
    public function getAssetElementByPath(
        UserInterface $user,
        string $path,
    ): AssetModel {
        $asset = $this->getElementByPath($this->serviceResolver, ElementTypes::TYPE_ASSET, $path);
        $this->securityService->hasElementPermission($asset, $user, ElementPermissions::VIEW_PERMISSION);

        if (!$asset instanceof AssetModel) {
            throw new InvalidElementTypeException($asset->getType());
        }

        return $asset;
    }

    public function getUniqueAssetName(string $targetPath, string $filename): string
    {
        $pathInfo = pathinfo($filename);
        $extension = empty($pathInfo['extension']) ? '' : '.' . $pathInfo['extension'];
        $count = 1;

        if ($targetPath === '/') {
            $targetPath = '';
        }

        while (true) {
            if ($this->assetServiceResolver->pathExists($targetPath . '/' . $filename)) {
                $filename = $pathInfo['filename'] . '_' . $count . $extension;
                $count++;
            } else {
                return $filename;
            }
        }
    }

    /**
     * @throws DatabaseException|ForbiddenException
     */
    public function clearThumbnails(int $id): void
    {
        $asset = $this->getAsset($id);

        if (!$asset->getPermissions()->isPublish()) {
            throw new ForbiddenException('Not allowed to clear thumbnails for this asset');
        }

        $asset = $this->serviceResolver->getElementById('asset', $id);

        $asset->clearThumbnails(true); // force clear

        try {
            $asset->save();
        } catch (Exception $e) {
            throw new DatabaseException($e->getMessage());
        }
    }

    private function dispatchAssetEvent(mixed $asset): void
    {
        $this->eventDispatcher->dispatch(
            new AssetEvent($asset),
            AssetEvent::EVENT_NAME
        );
    }
}
