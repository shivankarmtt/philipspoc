<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Asset\Service;

use League\Flysystem\FilesystemException;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\BasicStreamConfigParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\DynamicConfigurationParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\ImageDownloadConfigParameter;
use Pimcore\Bundle\StudioBackendBundle\Asset\MappedParameter\VideoImageStreamConfigParameter;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ElementProcessingNotCompletedException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ElementStreamResourceNotFoundException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidElementTypeException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidThumbnailConfigurationException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\InvalidThumbnailException;
use Pimcore\Model\Asset;
use Pimcore\Model\Element\ElementInterface;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * @internal
 */
interface BinaryServiceInterface
{
    /**
     * @throws ElementProcessingNotCompletedException
     * @throws InvalidElementTypeException
     * @throws InvalidThumbnailException
     * @throws FilesystemException
     */
    public function downloadVideoByThumbnail(
        Asset $video,
        string $thumbnailName
    ): StreamedResponse;

    /**
     * @throws ElementStreamResourceNotFoundException|InvalidElementTypeException
     */
    public function streamImage(
        Asset $image
    ): StreamedResponse;

    /**
     * @throws ElementStreamResourceNotFoundException|InvalidElementTypeException|InvalidThumbnailException
     */
    public function streamImageByThumbnail(
        ElementInterface $image,
        string $thumbnailName,
        ?BasicStreamConfigParameter $parameter = null
    ): StreamedResponse;

    /**
     * @throws InvalidElementTypeException|InvalidThumbnailException
     */
    public function streamPreviewImageThumbnail(Asset $image): StreamedResponse;

    /**
     * @throws InvalidElementTypeException|InvalidThumbnailException
     */
    public function streamImageThumbnailFromConfig(
        Asset $image,
        ImageDownloadConfigParameter $configParameter
    ): StreamedResponse;

    /**
     * @throws InvalidElementTypeException|InvalidThumbnailException
     */
    public function streamDynamicImageThumbnail(
        Asset $image,
        DynamicConfigurationParameter $parameter
    ): StreamedResponse;

    /**
     * @throws ElementProcessingNotCompletedException
     * @throws InvalidElementTypeException
     * @throws InvalidThumbnailException
     * @throws FilesystemException
     */
    public function streamVideoByThumbnail(
        Asset $video,
        string $thumbnailName
    ): StreamedResponse;

    /**
     * @throws ElementStreamResourceNotFoundException
     * @throws InvalidElementTypeException
     * @throws InvalidThumbnailConfigurationException
     * @throws InvalidThumbnailException
     */
    public function streamVideoImageThumbnail(
        Asset $video,
        VideoImageStreamConfigParameter $imageConfig
    ): StreamedResponse;
}
