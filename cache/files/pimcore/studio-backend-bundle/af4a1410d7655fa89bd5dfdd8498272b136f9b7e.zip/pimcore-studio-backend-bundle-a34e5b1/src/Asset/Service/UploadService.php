<?php
declare(strict_types=1);

/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

namespace Pimcore\Bundle\StudioBackendBundle\Asset\Service;

use Exception;
use League\Flysystem\FilesystemException;
use Pimcore\Bundle\GenericDataIndexBundle\Service\SearchIndex\IndexQueue\SynchronousProcessingServiceInterface;
use Pimcore\Bundle\GenericExecutionEngineBundle\Agent\JobExecutionAgentInterface;
use Pimcore\Bundle\GenericExecutionEngineBundle\Model\Job;
use Pimcore\Bundle\GenericExecutionEngineBundle\Model\JobStep;
use Pimcore\Bundle\StaticResolverBundle\Models\Asset\AssetResolverInterface;
use Pimcore\Bundle\StaticResolverBundle\Models\Asset\AssetServiceResolverInterface;
use Pimcore\Bundle\StaticResolverBundle\Models\Element\ServiceResolverInterface;
use Pimcore\Bundle\StudioBackendBundle\Asset\ExecutionEngine\AutomationAction\Messenger\Messages\AssetUploadMessage;
use Pimcore\Bundle\StudioBackendBundle\Asset\ExecutionEngine\Util\JobSteps;
use Pimcore\Bundle\StudioBackendBundle\Asset\Schema\AssetInfo;
use Pimcore\Bundle\StudioBackendBundle\Element\Service\StorageServiceInterface;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\DatabaseException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\EnvironmentException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\ForbiddenException;
use Pimcore\Bundle\StudioBackendBundle\Exception\Api\NotFoundException;
use Pimcore\Bundle\StudioBackendBundle\ExecutionEngine\Util\Config;
use Pimcore\Bundle\StudioBackendBundle\ExecutionEngine\Util\EnvironmentVariables;
use Pimcore\Bundle\StudioBackendBundle\ExecutionEngine\Util\Jobs;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\ElementPermissions;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\ElementTypes;
use Pimcore\Bundle\StudioBackendBundle\Util\Constant\HttpResponseErrorKeys;
use Pimcore\Helper\MimeTypeHelper;
use Pimcore\Model\Asset\Folder;
use Pimcore\Model\Element\ElementDescriptor;
use Pimcore\Model\Element\ElementInterface;
use Pimcore\Model\UserInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use function dirname;
use function sprintf;

/**
 * @internal
 */
final readonly class UploadService implements UploadServiceInterface
{
    public function __construct(
        private AssetServiceInterface $assetService,
        private AssetResolverInterface $assetResolver,
        private AssetServiceResolverInterface $assetServiceResolver,
        private JobExecutionAgentInterface $jobExecutionAgent,
        private ServiceResolverInterface $serviceResolver,
        private StorageServiceInterface $storageService,
        private SynchronousProcessingServiceInterface $synchronousProcessingService,
    ) {

    }

    /**
     * @throws ForbiddenException
     * @throws NotFoundException
     */
    public function fileExists(
        int $parentId,
        string $fileName,
        UserInterface $user
    ): AssetInfo {
        $parent = $this->assetService->getAssetElement($user, $parentId);
        $filePath = $parent->getRealFullPath() . '/' . $fileName;
        $exists = $this->assetServiceResolver->pathExists($filePath, ElementTypes::TYPE_ASSET);

        if ($exists === false) {
            return new AssetInfo(false);
        }

        $asset = $this->assetService->getAssetElementByPath($user, $filePath);

        return  new AssetInfo(true, $asset->getId());
    }

    /**
     * @throws DatabaseException
     * @throws EnvironmentException
     * @throws FilesystemException
     * @throws ForbiddenException
     * @throws NotFoundException
     */
    public function uploadAsset(
        int $parentId,
        string $fileName,
        string $filePath,
        UserInterface $user,
        bool $useFlysystem = false,
        ?string $assetType = null
    ): int {
        $parent = $this->validateParent($user, $parentId);
        $fileName = $this->getValidFileName($fileName);
        if ($assetType !== null && $assetType !== '') {
            $this->validateMimeType($filePath, $fileName, $assetType);
        }

        $uniqueName = $this->assetService->getUniqueAssetName($parent->getRealFullPath(), $fileName);
        $userId = $user->getId();
        $assetParams = [
            'filename' => $uniqueName,
            'userOwner' => $userId,
            'userModification' => $userId,
        ];
        $this->synchronousProcessingService->enable();

        if ($useFlysystem) {
            return $this->uploadAssetFromFlysystem($parentId, $assetParams, $filePath);
        }

        return $this->uploadAssetLocally($parentId, $assetParams, $filePath);
    }

    public function uploadParentFolder(string $filePath, int $rootParentId, UserInterface $user): int
    {
        $rootParent = $this->validateParent($user, $rootParentId);
        $this->synchronousProcessingService->enable();
        $parent = $this->assetServiceResolver->createFolderByPath(
            $rootParent->getRealFullPath() . '/' . preg_replace('@^/@', '', dirname($filePath))
        );

        return $parent->getId();
    }

    /**
     * @throws EnvironmentException
     */
    public function uploadAssetsAsynchronously(
        UserInterface $user,
        array $files,
        int $parentId,
        string $folderName,
    ): int {
        $job = new Job(
            name: Jobs::UPLOAD_ASSETS->value,
            steps: [
                new JobStep(JobSteps::ASSET_UPLOADING->value, AssetUploadMessage::class, '', []),
            ],
            selectedElements: array_map(static function ($file, $index) {
                try {
                    $fileData = json_encode($file, JSON_THROW_ON_ERROR);

                    return new ElementDescriptor($fileData, $index);
                } catch (Exception $e) {
                    throw new EnvironmentException($e->getMessage());
                }
            }, $files, array_keys($files)),
            environmentData: [
                EnvironmentVariables::PARENT_ID->value => $parentId,
                EnvironmentVariables::UPLOAD_FOLDER_LOCATION->value => $folderName,
            ]
        );
        $jobRun = $this->jobExecutionAgent->startJobExecution(
            $job,
            $user->getId(),
            Config::CONTEXT_CONTINUE_ON_ERROR->value
        );

        return $jobRun->getId();
    }

    /**
     * @throws DatabaseException
     * @throws EnvironmentException
     * @throws ForbiddenException
     * @throws NotFoundException
     */
    public function replaceAssetBinary(
        int $assetId,
        UploadedFile $file,
        UserInterface $user
    ): string {
        $asset = $this->assetService->getAssetElement($user, $assetId);
        if (!$asset->isAllowed(ElementPermissions::PUBLISH_PERMISSION)) {
            throw new ForbiddenException(
                sprintf(
                    'Missing permissions on target Asset %s',
                    $asset->getId()
                )
            );
        }

        $sourcePath = $this->getValidSourcePath($file->getRealPath());
        $fileName = $this->getValidFileName($file->getClientOriginalName());
        $this->validateMimeType($file->getRealPath(), $fileName, $asset->getType());

        try {
            $newFileName = $this->getUpdatedFileName($asset->getFilename(), $fileName, $asset->getParent());
            $asset->setStream(fopen($sourcePath, 'rb'));
            $asset->setCustomSetting('thumbnails', null);
            if (method_exists($asset, 'getEmbeddedMetaData')) {
                $asset->getEmbeddedMetaData(true);
            }
            $asset->setUserModification($user->getId());
            $asset->setFilename($newFileName);
            $asset->save();

            return $newFileName;
        } catch (Exception $e) {
            throw new DatabaseException($e->getMessage());
        } finally {
            @unlink($sourcePath);
        }
    }

    /**
     * @throws EnvironmentException|ForbiddenException|NotFoundException
     */
    public function validateParent(UserInterface $user, int $parentId): ElementInterface
    {
        $parent = $this->assetService->getAssetElement($user, $parentId);
        if (!$parent->isAllowed(ElementPermissions::CREATE_PERMISSION)) {
            throw new ForbiddenException(
                sprintf(
                    'Missing permissions on target Asset %s',
                    $parent->getId()
                )
            );
        }

        if (!$parent instanceof Folder) {
            throw new EnvironmentException('Invalid parent type: ' . $parent->getType());
        }

        return $parent;
    }

    public function sanitizeFileToUpload(string $fileName): ?string
    {
        if (str_starts_with($fileName, '__MACOSX/') ||
            str_ends_with($fileName, '/Thumbs.db')) {
            return null;
        }

        return $fileName;
    }

    /**
     * @throws FilesystemException
     */
    public function cleanupTemporaryUploadFiles(string $location): void
    {
        $this->storageService->cleanUpFolder($location, true);
        $this->storageService->cleanUpLocalFolder(PIMCORE_SYSTEM_TEMP_DIRECTORY . '/' . $location);
    }

    /**
     * @throws DatabaseException
     * @throws EnvironmentException
     */
    private function uploadAssetLocally(
        int $parentId,
        array $assetParams,
        string $sourcePath,
    ): int {
        $assetParams['sourcePath'] = $this->getValidSourcePath($sourcePath);

        try {
            $asset = $this->assetResolver->create(
                $parentId,
                $assetParams
            );
        } catch (Exception $e) {
            throw new DatabaseException($e->getMessage());
        } finally {
            @unlink($sourcePath);
        }

        return $asset->getId();
    }

    /**
     * @throws FilesystemException|EnvironmentException
     */
    private function uploadAssetFromFlysystem(
        int $parentId,
        array $assetParams,
        string $sourcePath,
    ): int {
        $storage = $this->storageService->getTempStorage();
        $assetParams['stream'] = $storage->readStream($sourcePath);

        try {
            $asset = $this->assetResolver->create(
                $parentId,
                $assetParams
            );
        } catch (Exception $e) {
            throw new EnvironmentException($e->getMessage());
        } finally {
            $storage->delete($sourcePath);
        }

        return $asset->getId();
    }

    /**
     * @throws EnvironmentException
     */
    private function getValidSourcePath(string $sourcePath): string
    {
        if (!is_file($sourcePath)) {
            throw new EnvironmentException(
                'Something went wrong, please check upload_max_filesize and post_max_size in your php.ini ' .
                ' as well as the write permissions of your temporary directories.'
            );
        }

        if (filesize($sourcePath) < 1) {
            throw new EnvironmentException('File is empty!');
        }

        return $sourcePath;
    }

    /**
     * @throws EnvironmentException
     */
    private function getValidFileName(string $originalFileName): string
    {
        $fileName = $this->serviceResolver->getValidKey(
            $originalFileName,
            ElementTypes::TYPE_ASSET
        );

        if ($fileName === '') {
            throw new EnvironmentException('Invalid filename');
        }

        return $fileName;
    }

    private function getUpdatedFileName(
        string $originalFileName,
        string $newFileName,
        ElementInterface $parent
    ): string {
        $newExtension = pathinfo($newFileName, PATHINFO_EXTENSION);
        $originalExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);
        if ($newExtension === $originalExtension) {
            return $originalFileName;
        }

        $fileName = preg_replace(
            '/\.' . $originalExtension . '$/i',
            '.' . $newExtension,
            $originalFileName
        );

        return $this->serviceResolver->getSafeCopyName($fileName, $parent);
    }

    private function validateMimeType(
        string $filePath,
        string $fileName,
        string $assetType
    ): void {
        $mimeTypes = new MimeTypeHelper();
        $mimeType = $mimeTypes->guessMimeType($filePath);
        $newType = $this->assetResolver->getTypeFromMimeMapping($mimeType, $fileName);

        if ($newType !== $assetType) {
            throw new EnvironmentException(
                sprintf(
                    'Inconsistent asset binary types: required asset (%s) - new asset (%s)',
                    $assetType,
                    $newType
                ),
                HttpResponseErrorKeys::INVALID_ASSET_TYPE->value
            );
        }
    }
}
