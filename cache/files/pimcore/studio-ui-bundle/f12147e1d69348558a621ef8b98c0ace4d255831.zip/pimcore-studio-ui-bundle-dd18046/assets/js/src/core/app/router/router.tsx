/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { DeepLink } from '@Pimcore/components/deep-link/deep-link'
import { DefaultPage } from '@Pimcore/modules/app/default-page'
import { useIsAuthenticated } from '@Pimcore/modules/auth/hooks/use-is-authenticated'
import { LoginPage } from '@Pimcore/modules/auth/login-page'
import React from 'react'
import { createBrowserRouter, Navigate, useLocation } from 'react-router-dom'
import { appConfig } from '../config/app-config'
import { PasswordReset } from '@Pimcore/components/password-reset/password-reset'

export const baseUrl = appConfig.baseUrl.endsWith('/')
  ? appConfig.baseUrl.slice(0, -1) + '/'
  : appConfig.baseUrl

export const LOGIN_URL = `${baseUrl}login/`
export const DEEP_LINK_URL = `${baseUrl}:elementType/:id`
export const PASSWORD_RESET_URL = `${baseUrl}reset-password/`

export const routes = {
  root: baseUrl,
  login: LOGIN_URL,
  deeplinkAsset: DEEP_LINK_URL,
  passwordReset: PASSWORD_RESET_URL
}

const AuthenticatedRoute = ({ children }: { children: React.JSX.Element }): React.ReactElement => {
  const { isAuthenticated } = useIsAuthenticated()
  const location = useLocation()

  return (
    <>
      {isAuthenticated === true && children}
      {isAuthenticated === false && (
        <Navigate
          state={ { from: location } }
          to={ routes.login }
        />
      )}
    </>
  )
}

export const router = createBrowserRouter([
  {
    path: routes.root,
    element: <AuthenticatedRoute>
      <DefaultPage />
    </AuthenticatedRoute>
  },
  {
    path: routes.login,
    element: <LoginPage />
  },
  {
    path: routes.deeplinkAsset,
    element: <AuthenticatedRoute>
      <DeepLink />
    </AuthenticatedRoute>
  },
  {
    path: routes.passwordReset,
    element: <PasswordReset />
  }
])
