/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { type FormItemProps, type Form } from 'antd'
import React, { useMemo } from 'react'
import { useLocalizedFields } from '../provider/localized-fields-provider/use-localized-fields'
import { isArray } from 'lodash'
import { Text } from '@Pimcore/components/text/text'
import { LocalizedFormItemControl } from './localized-form-item-control'

export const withLocalizedFieldsLocale = (Component: typeof Form.Item): typeof Form.Item => {
  const FormItemWithLocalizedFieldsLocale = (props: FormItemProps): React.JSX.Element => {
    const context = useLocalizedFields()

    return useMemo(() => {
      if (context === undefined) {
        return <Component { ...props } />
      }

      const { locales } = context
      const { name, label, children, ...baseProps } = props
      const newName = [...(isArray(name) ? name : [name]), locales[0]]
      const currentChildren = children as unknown as React.ReactNode
      const newLabel = (
        <>
          {label} <Text type='secondary'>({locales[0].toUpperCase()})</Text>
        </>
      )

      return (
        <Component
          { ...baseProps }
          label={ newLabel }
          name={ newName }
        >
          <LocalizedFormItemControl { ...context }>
            { currentChildren }
          </LocalizedFormItemControl>
        </Component>
      )
    }, [context, props])
  }

  const NewFormItem = FormItemWithLocalizedFieldsLocale as typeof Form.Item
  NewFormItem.useStatus = Component.useStatus
  return NewFormItem
}
