/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { container } from '../depency-injection'
import { documentApi, type DocumentApi } from './document/document-api'
import { i18nApi, type I18nApi } from './i18n/i18n-api'
import { elementApi, type ElementApi } from './element/element-api'
import { modalApi, type ModalApi } from './modal/modal-api'
import { settingsApi, type SettingsApi } from './settings/settings-api'

export interface PublicApi {
  container: typeof container
}

export const Pimcore: PublicApi = {
  container
}

export interface PimcoreStudioApi {
  document: DocumentApi
  i18n: I18nApi
  element: ElementApi
  modal: ModalApi
  settings: SettingsApi
}

export const PimcoreStudio: PimcoreStudioApi = {
  document: documentApi,
  i18n: i18nApi,
  element: elementApi,
  modal: modalApi,
  settings: settingsApi
}
