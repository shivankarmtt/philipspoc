/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import React from 'react'
import { Flex } from '@Pimcore/components/flex/flex'
import { Text } from '@Pimcore/components/text/text'

export interface CollapseHeaderProps {
  label?: React.ReactNode
  subLabel?: React.ReactNode
  subLabelPosition?: 'inline' | 'block'
  extra?: React.ReactNode
  extraPosition?: 'start' | 'end'
  expandIcon?: React.ReactNode
  expandIconPosition?: 'start' | 'end' | 'left' | 'right'
}

export const CollapseHeader = ({ label, subLabel, extra, extraPosition, expandIcon, expandIconPosition, subLabelPosition = 'block' }: CollapseHeaderProps): React.JSX.Element => {
  const extraAdjustment = extraPosition === 'start' ? 'flex-start' : 'flex-end'

  return (
    <Flex
      align='center'
      gap={ 'extra-small' }
    >
      <Flex
        className={ 'collapse-header__title-container' }
        gap={ 4 }
        vertical={ subLabelPosition === 'block' }
      >
        <Flex
          align='center'
          gap={ 'mini' }
        >
          {(expandIconPosition === 'start' || expandIconPosition === 'left') && expandIcon}
          <Text className={ 'collapse-header__title' }>{label}</Text>
          {(expandIconPosition === 'end' || expandIconPosition === 'right') && expandIcon}
        </Flex>

        {subLabel !== undefined && (
          <Text
            className='collapse-header__subtitle'
            type='secondary'
          >{subLabel}</Text>
        )}
      </Flex>

      {
        extra !== undefined && (
          <Flex
            className='collapse-header__extra'
            justify={ extraAdjustment }
          >
            {extra}
          </Flex>
        )
      }
    </Flex >
  )
}
