/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { container } from '@Pimcore/app/depency-injection'
import { serviceIds } from '@Pimcore/app/config/services/service-ids'
import { type DynamicTypeDocumentEditableRegistry } from '@Pimcore/modules/element/dynamic-types/definitions/document/editable/dynamic-type-document-editable-registry'
import { type AbstractDocumentEditableDefinition } from '@Pimcore/modules/element/dynamic-types/definitions/document/editable/dynamic-type-document-editable-abstract'
import { isNil } from 'lodash'

export interface ValueType { type: string, data: any }

export interface DocumentEditableApi {
  getValues: (forApi?: boolean) => Record<string, ValueType>
  getValue: (key: string) => ValueType
  updateValue: (key: string, value: ValueType) => void
  initializeValues: (initialValues: Record<string, ValueType>) => void
  removeValues: (keysToRemove: string[]) => void
  getInheritanceState: (key: string) => boolean
  setInheritanceState: (key: string, inherited: boolean) => void
  initializeInheritanceState: (inheritanceState: Record<string, boolean>) => void
  getEditableDefinitions: () => AbstractDocumentEditableDefinition[]
  registerDynamicEditables: (editables: AbstractDocumentEditableDefinition[]) => void
  unregisterDynamicEditables: (editableIds: string[]) => void
}

class DocumentEditableApiImpl implements DocumentEditableApi {
  private values: Record<string, ValueType> = {}
  private inheritanceState: Record<string, boolean> = {}
  private dynamicEditables: Record<string, AbstractDocumentEditableDefinition> = {}

  getValues (forApi: boolean = false): Record<string, ValueType> {
    if (!forApi) {
      return { ...this.values }
    }

    try {
      const transformedValues: Record<string, ValueType> = {}

      for (const [editableName, editableValue] of Object.entries(this.values)) {
        const transformedValue = this.transformEditableValue(editableName, editableValue)
        transformedValues[editableName] = transformedValue
      }

      return transformedValues
    } catch (error) {
      console.warn('Could not apply transformValueForApi transformations:', error)
      return { ...this.values }
    }
  }

  getValue (key: string): ValueType {
    return this.values[key]
  }

  updateValue (key: string, value: ValueType): void {
    this.values[key] = value
  }

  initializeValues (initialValues: Record<string, ValueType>): void {
    Object.assign(this.values, initialValues)
  }

  removeValues (keysToRemove: string[]): void {
    for (const key of keysToRemove) {
      // eslint-disable-next-line @typescript-eslint/no-dynamic-delete
      delete this.values[key]
    }
  }

  getInheritanceState (key: string): boolean {
    return this.inheritanceState[key] ?? false
  }

  setInheritanceState (key: string, inherited: boolean): void {
    this.inheritanceState[key] = inherited
  }

  initializeInheritanceState (inheritanceState: Record<string, boolean>): void {
    Object.assign(this.inheritanceState, inheritanceState)
  }

  registerDynamicEditables (editables: AbstractDocumentEditableDefinition[]): void {
    for (const editable of editables) {
      this.dynamicEditables[editable.id] = editable
    }
  }

  unregisterDynamicEditables (editableIds: string[]): void {
    for (const id of editableIds) {
      // eslint-disable-next-line @typescript-eslint/no-dynamic-delete
      delete this.dynamicEditables[id]
    }
  }

  getEditableDefinitions (): AbstractDocumentEditableDefinition[] {
    const getInitialEditables = (): AbstractDocumentEditableDefinition[] => {
      try {
        const iframeWindow = window as any
        return iframeWindow.editableDefinitions ?? []
      } catch (error) {
        console.warn('Could not get editable definitions from iframe window:', error)
        return []
      }
    }

    const initialEditables = getInitialEditables()
    const dynamicEditables = Object.values(this.dynamicEditables)

    const allEditables = [...initialEditables, ...dynamicEditables.filter(
      dynamic => !initialEditables.some(initial => initial.id === dynamic.id)
    )]

    // Filter to only include editables that have values. Editables without values are removed by the user.
    return allEditables.filter(editable => editable.name in this.values)
  }

  private transformEditableValue (editableName: string, editableValue: ValueType): ValueType {
    const editableDefinitions = this.getEditableDefinitions()
    const editableDefinition = editableDefinitions.find(def => def.name === editableName)

    if (isNil(editableDefinition)) {
      return editableValue
    }

    const dynamicType = this.getDynamicTypeForEditable(editableDefinition.type)

    if (isNil(dynamicType)) {
      return editableValue
    }

    const apiValue = dynamicType.transformValueForApi(editableValue.data, editableDefinition)

    return {
      type: editableValue.type,
      data: apiValue
    }
  }

  private getDynamicTypeForEditable (editableType: string): any {
    try {
      const documentEditableRegistry = container.get<DynamicTypeDocumentEditableRegistry>(
        serviceIds['DynamicTypes/DocumentEditableRegistry']
      )

      if (!documentEditableRegistry.hasDynamicType(editableType)) {
        return null
      }

      return documentEditableRegistry.getDynamicType(editableType)
    } catch (error) {
      console.warn(`Could not get dynamic type for editable type "${editableType}":`, error)
      return null
    }
  }
}

export const documentEditableApi = new DocumentEditableApiImpl()
