/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import React from 'react'
import PimcoreLogo from '@Pimcore/assets/images/pimcore.inline.svg?react'
import { useStlyes } from './logo.styles'
import { Flex } from '@Pimcore/components/flex/flex'

export const Logo = (): React.JSX.Element => {
  const { styles } = useStlyes()

  return (
    <Flex
      align='center'
      className={ ['logo', styles.logo].join(' ') }
      justify="center"
      style={ { display: 'inline-flex' } }
    >
      <PimcoreLogo
        height={ 24 }
        width={ 24 }
      />
    </Flex>
  )
}
