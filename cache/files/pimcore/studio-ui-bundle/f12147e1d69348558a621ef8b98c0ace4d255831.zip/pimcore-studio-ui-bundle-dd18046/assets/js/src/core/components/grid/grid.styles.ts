/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { createStyles, type SerializedStyles } from 'antd-style'
import { type GridProps } from '@Pimcore/types/components/types'

const BORDER_WIDTH = 1

export interface UseStylesProps {
  size?: GridProps['size']
  enableVirtualizer?: boolean
}

export const useStyles = createStyles(({ token, css }, { size = 'normal', enableVirtualizer = false }: UseStylesProps) => {
  const rowHeight = size === 'small' ? 32 : 41
  const rowHeightValue = enableVirtualizer ? 'auto' : `${rowHeight}px`
  const paddingValue = size !== 'small' && enableVirtualizer ? `${token.paddingXXS}px 0 !important` : 0

  const hideBorder = (side: 'left' | 'right'): SerializedStyles => css`
    content: '';
    display: block;
    position: absolute;
    top: -${BORDER_WIDTH}px;
    ${side}: -${BORDER_WIDTH}px;
    width: 100%;
    height: 100%;
    background: ${token.colorBgContainer};
    z-index: -1;
  `

  return {
    grid: css`
      display: flex; 
      width: 100%;
      max-width: 100%;

      table {
        table-layout: fixed;
        width: auto;
        height: 0;
      }

      &.grid--docked {
        &.ant-table-wrapper .ant-table-container,
        &.ant-table-wrapper .ant-table,
        &.ant-table-wrapper table {
          border-radius: 0;
          border: 0;
        }

        &.ant-table-wrapper .ant-table-container table>thead>tr:first-child >*:first-child,
        &.ant-table-wrapper .ant-table-container table>thead>tr:first-child >*:last-child {
          border-radius: 0;
        }

        .ant-table-cell:first-of-type {
          border-left: 0;
        }

        .ant-table-cell:last-of-type {
          border-right: 0;
        }

        tr:last-of-type {
          .ant-table-cell {
            border-bottom: 0;
          }
        }
      }

      table.withoutHeader {
        .ant-table-tbody {
          .ant-table-row:first-child {
            .ant-table-cell {
              border-top: ${BORDER_WIDTH}px solid ${token.Table.colorBorderSecondary} !important;
            }

            .ant-table-cell:first-of-type {
              border-top-left-radius: 8px;

              .default-cell--active {
                  border-top-left-radius: 7px;
              }
            }

            .ant-table-cell:last-of-type {
              border-top-right-radius: 8px;
              
              .default-cell--active {
                border-top-right-radius: 7px;
              }
            }
          }

          .ant-table-row:last-of-type {
            .ant-table-cell:first-of-type {
              .default-cell--active {
                border-bottom-left-radius: 7px;
              }
            }

            .ant-table-cell:last-of-type {
              .default-cell--active {
                border-bottom-right-radius: 7px;
              }
            }
          }
        }
      }

      th {
        user-select: none;
      }

      th, td {
        line-height: 1.83;
        padding: ${token.Table.cellPaddingBlockSM}px ${token.Table.cellPaddingInlineSM}px;
      }

      &.ant-table-wrapper .ant-table.ant-table-small .ant-table-thead>tr>th {
        padding: ${token.paddingXXS}px ${token.paddingXS}px;
      }

      &.ant-table-wrapper .ant-table.ant-table-small .ant-table-tbody>tr>td {
        padding: 0;
      }

      .ant-table-cell {
        position: relative;
        border-left: ${BORDER_WIDTH}px solid ${token.Table.colorBorderSecondary};
        white-space: nowrap;
        text-overflow: ellipsis;

        &.ant-table-cell__no-data {
          padding: ${token.paddingXS}px 0px ${token.paddingXS}px ${token.paddingXS}px !important;
        }

        &:last-of-type {
          border-right: ${BORDER_WIDTH}px solid #F0F0F0;
        }
      }
      
      .ant-table-cell:last-of-type {
        border-color: ${token.Table.colorBorderSecondary} !important;
      }

      .ant-table-thead {
        position: sticky;
        top: 0;
        z-index: 1;

        .ant-table-cell {
          border-top: ${BORDER_WIDTH}px solid ${token.Table.colorBorderSecondary} !important;
        }

        .ant-table-cell:first-child {
          &::after {
            ${hideBorder('left')}
          }
        }

        .ant-table-cell:last-of-type {
          border-color: ${token.Table.colorBorderSecondary} !important;
          
          &::before {
            ${hideBorder('right')}
          }
        }

        .grid__cell-content {
          display: flex;
          width: 100%;
          justify-content: space-between;
          align-items: center;
        }

        .grid__sorter {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          width: 26px;
        }
      }

      .ant-table-row {
        height: ${rowHeightValue};
          
        .ant-table-cell {
          padding: ${paddingValue};
        }
      }

      .ant-table-content {
        table {
          border: ${BORDER_WIDTH}px solid transparent;
          border-radius: 8px;
        }
          
          .ant-table-tbody {
            position: relative;
            width: 100%;
              
            .ant-table-row:last-of-type {
              .ant-table-cell:first-of-type {
                border-bottom-left-radius: 8px;
              }
              
              .ant-table-cell:last-of-type {
                border-bottom-right-radius: 8px;
                border-color: ${token.Table.colorBorderSecondary} !important;
              }
            }
          }
      }
      
      &.versionFieldItem {
        .ant-table-content {
          table {
            width: 100% !important;
            min-width: 100% !important;
            table-layout: auto;
              
            .ant-table-cell {
              width: inherit !important;
              min-width: inherit !important;
            }
          }
        }
      }

      &.versionFieldItemHighlight {
        .ant-table-content {
          table {
            border-color: ${token.Colors.Brand.Warning.colorWarningBorder} !important;
          }
        }
      }

      .grid__cell-content {
        display: flex;
        width: 100%;
        height: 100%;
          
        .ant-skeleton {
          width: 100%;
          margin: 4px;
            
            .ant-skeleton-input {
              min-width: unset;
              width: 100%;
            }
        }
      }

      .grid__cell-content > * {
        display: flex;
        width: 100%;
        height: 100%;
      }

      .ant-table-row-selected td {
        background-color: ${token.controlItemBgActive};
      }
    `,

    disabledGrid: css`
      .ant-table-cell {
        background-color: ${token.colorBgContainerDisabled};
        color: ${token.colorTextDisabled};
      }
    `
  }
}, { hashPriority: 'low' })
