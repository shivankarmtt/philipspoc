/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { Button } from '@Pimcore/components/button/button'
import React, { type MouseEvent, useEffect, useState } from 'react'
import { Icon } from '@Pimcore/components/icon/icon'
import { useStyles } from './langguage-selection.styles'
import { FlagIcon } from '@Pimcore/components/flag-icon/flag-icon'
import { useTranslation } from 'react-i18next'

interface LanguageSelectionProps {
  languages: string[]
  customKeys?: string[]
  selectedLanguage: string
  onSelectLanguage: (language: string) => void
}

export const transformLanguage = (language: string): string | null => language === '-' ? null : language

export const LanguageSelection = ({ languages, customKeys = [], selectedLanguage, onSelectLanguage }: LanguageSelectionProps): React.JSX.Element => {
  const { styles } = useStyles()
  const [language, setLanguage] = useState<string>(selectedLanguage)
  const { t } = useTranslation()

  useEffect(() => {
    setLanguage(selectedLanguage)
  }, [selectedLanguage])

  return (
    <div className={ ['language-select', styles.languageSelect].join(' ') }>
      <Button
        onClick={ goToPreviousLanguage }
        type='link'
      >
        <Icon
          options={ { width: 18, height: 18 } }
          value='chevron-left'
        />
      </Button>

      <div className='language-select__current-value'>
        { language === '-' && (
        <Icon
          options={ { width: 18, height: 18 } }
          value='minus'
        />
        )}

        {customKeys.includes(language) && (
          <span>{ t(`custom-language.${language}`) }</span>
        )}

        { language !== '-' && !customKeys.includes(language) && (
          <>
            <FlagIcon value={ transformLanguage(language) } />
            <span>{ language }</span>
          </>
        )}
      </div>

      <Button
        onClick={ goToNextLanguage }
        type='link'
      >
        <Icon
          options={ { width: 18, height: 18 } }
          value='chevron-right'
        />
      </Button>
    </div>
  )

  function goToNextLanguage (e: MouseEvent): void {
    e.stopPropagation()
    const currentIndex = languages.indexOf(language)
    const nextIndex = currentIndex === languages.length - 1 ? 0 : currentIndex + 1
    handleLanguageChange(languages[nextIndex])
  }

  function goToPreviousLanguage (e: MouseEvent): void {
    e.stopPropagation()
    const currentIndex = languages.indexOf(language)
    const previousIndex = currentIndex === 0 ? languages.length - 1 : currentIndex - 1
    handleLanguageChange(languages[previousIndex])
  }

  function handleLanguageChange (language: string): void {
    setLanguage(language)
    onSelectLanguage(language)
  }
}
