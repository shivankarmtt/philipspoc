/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import type { Meta, StoryObj } from '@storybook/react'
import React from 'react'
import { Region } from '@Pimcore/components/region/region'
import { Panel } from '@Pimcore/components/panel/panel'
import { FormKit } from '../../form-kit'
import { Input } from '@Pimcore/components/input/input'
import { InputNumber } from '@Pimcore/components/input-number/input-number'
import { TextArea } from '@Pimcore/components/textarea/textarea'
import { Select } from '@Pimcore/components/select/select'
import { Switch } from '@Pimcore/components/switch/switch'
import { Button } from '@Pimcore/components/button/button'
import { Space } from '@Pimcore/components/space/space'
import { useCssContainer } from '@Pimcore/utils/hooks/use-css-container/use-css-container'
import { cssContainerWidget } from '@Pimcore/modules/widget-manager/widget/widget-view'
import { Form } from '../../form'

// Container wrapper to provide CSS container context for Region responsive behavior
const FormLayoutContainer = ({ children }: { children: React.ReactNode }): React.JSX.Element => {
  const { styleDefinition } = useCssContainer(cssContainerWidget)

  return (
    <div
      className={ styleDefinition.styles.container }
      style={ { width: '100%' } }
    >
      {children}
    </div>
  )
}

const meta: Meta<typeof Region> = {
  title: 'Components/Data Entry/Form/Layouts/Region',
  component: Region,
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component: 'Use Region as the layout container to organize multiple Panel components in complex form layouts. Region handles positioning while Panel provides content structure.'
      }
    }
  },
  tags: ['autodocs']
}

export default meta
type Story = StoryObj<typeof meta>

// Two-Column Form Layout
const TwoColumnFormComponent = (): React.JSX.Element => {
  const [form] = Form.useForm()

  return (
    <FormLayoutContainer>
      <div style={ { maxWidth: '1000px' } }>
        <FormKit formProps={ { form, layout: 'vertical' } }>
          <Region
            items={ [
              {
                region: 'left',
                component: (
                  <Panel
                    theme="card-with-highlight"
                    title="Personal Information"
                  >
                    <Form.Item
                      label="First Name"
                      name="firstName"
                    >
                      <Input placeholder="Enter first name" />
                    </Form.Item>

                    <Form.Item
                      label="Last Name"
                      name="lastName"
                    >
                      <Input placeholder="Enter last name" />
                    </Form.Item>

                    <Form.Item
                      label="Email"
                      name="email"
                    >
                      <Input placeholder="Enter email address" />
                    </Form.Item>

                    <Form.Item
                      label="Phone"
                      name="phone"
                    >
                      <Input placeholder="Enter phone number" />
                    </Form.Item>
                  </Panel>
                )
              },
              {
                region: 'right',
                component: (
                  <Panel
                    theme="card-with-highlight"
                    title="Address Information"
                  >
                    <Form.Item
                      label="Street Address"
                      name="address"
                    >
                      <TextArea
                        placeholder="Enter street address"
                        rows={ 2 }
                      />
                    </Form.Item>

                    <Form.Item
                      label="City"
                      name="city"
                    >
                      <Input placeholder="Enter city" />
                    </Form.Item>

                    <Form.Item
                      label="Postal Code"
                      name="postalCode"
                    >
                      <Input placeholder="Enter postal code" />
                    </Form.Item>

                    <Form.Item
                      label="Country"
                      name="country"
                    >
                      <Select
                        options={ [
                          { value: 'us', label: 'United States' },
                          { value: 'de', label: 'Germany' },
                          { value: 'uk', label: 'United Kingdom' },
                          { value: 'fr', label: 'France' }
                        ] }
                        placeholder="Select country"
                      />
                    </Form.Item>
                  </Panel>
                )
              }
            ] }
            layoutDefinition={ [
              'left right'
            ] }
          />

          <Form.Item style={ { marginTop: '24px' } }>
            <Button
              htmlType="submit"
              type="primary"
            >
              Save Information
            </Button>
          </Form.Item>
        </FormKit>
      </div>
    </FormLayoutContainer>
  )
}

export const TwoColumnForm: Story = {
  render: () => <TwoColumnFormComponent />
}

// Three-Section Layout
const ThreeSectionFormComponent = (): React.JSX.Element => {
  const [form] = Form.useForm()

  return (
    <FormLayoutContainer>
      <div style={ { maxWidth: '1200px' } }>
        <FormKit formProps={ { form, layout: 'vertical' } }>
          <Region
            items={ [
              {
                region: 'header',
                component: (
                  <Panel
                    border
                    theme="fieldset"
                    title="Basic Information"
                  >
                    <div style={ { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' } }>
                      <Form.Item
                        label="Title"
                        name="title"
                      >
                        <Select
                          options={ [
                            { value: 'mr', label: 'Mr.' },
                            { value: 'mrs', label: 'Mrs.' },
                            { value: 'ms', label: 'Ms.' },
                            { value: 'dr', label: 'Dr.' }
                          ] }
                          placeholder="Select title"
                        />
                      </Form.Item>

                      <Form.Item
                        label="First Name"
                        name="firstName"
                      >
                        <Input placeholder="Enter first name" />
                      </Form.Item>

                      <Form.Item
                        label="Last Name"
                        name="lastName"
                      >
                        <Input placeholder="Enter last name" />
                      </Form.Item>
                    </div>
                  </Panel>
                )
              },
              {
                region: 'main',
                component: (
                  <Panel
                    theme="card-with-highlight"
                    title="Contact Details"
                  >
                    <Form.Item
                      label="Email Address"
                      name="email"
                    >
                      <Input placeholder="Enter email address" />
                    </Form.Item>

                    <Form.Item
                      label="Phone Number"
                      name="phone"
                    >
                      <Input placeholder="Enter phone number" />
                    </Form.Item>

                    <Form.Item
                      label="Company"
                      name="company"
                    >
                      <Input placeholder="Enter company name" />
                    </Form.Item>

                    <Form.Item
                      label="Job Title"
                      name="jobTitle"
                    >
                      <Input placeholder="Enter job title" />
                    </Form.Item>

                    <Form.Item
                      label="Bio"
                      name="bio"
                    >
                      <TextArea
                        placeholder="Tell us about yourself..."
                        rows={ 4 }
                      />
                    </Form.Item>
                  </Panel>
                )
              },
              {
                region: 'sidebar',
                component: (
                  <Panel
                    collapsible
                    theme="card-with-highlight"
                    title="Preferences"
                  >
                    <Form.Item
                      label="Preferred Language"
                      name="language"
                    >
                      <Select
                        options={ [
                          { value: 'en', label: 'English' },
                          { value: 'de', label: 'German' },
                          { value: 'fr', label: 'French' },
                          { value: 'es', label: 'Spanish' }
                        ] }
                        placeholder="Select language"
                      />
                    </Form.Item>

                    <Form.Item
                      label="Newsletter"
                      name="newsletter"
                      valuePropName="checked"
                    >
                      <Switch />
                    </Form.Item>

                    <Form.Item
                      label="Marketing Emails"
                      name="marketing"
                      valuePropName="checked"
                    >
                      <Switch />
                    </Form.Item>

                    <Form.Item
                      label="SMS Notifications"
                      name="sms"
                      valuePropName="checked"
                    >
                      <Switch />
                    </Form.Item>
                  </Panel>
                )
              }
            ] }
            layoutDefinition={ [
              'header header header',
              'main sidebar sidebar'
            ] }
          />

          <div style={ { marginTop: '24px', display: 'flex', justifyContent: 'space-between' } }>
            <Button htmlType="reset">Reset Form</Button>
            <Space>
              <Button>Save as Draft</Button>
              <Button
                htmlType="submit"
                type="primary"
              >
                Submit Application
              </Button>
            </Space>
          </div>
        </FormKit>
      </div>
    </FormLayoutContainer>
  )
}

export const ThreeSectionForm: Story = {
  render: () => <ThreeSectionFormComponent />
}

// Sidebar Layout
const SidebarFormComponent = (): React.JSX.Element => {
  const [form] = Form.useForm()

  return (
    <FormLayoutContainer>
      <div style={ { maxWidth: '1000px' } }>
        <FormKit formProps={ { form, layout: 'vertical' } }>
          <Region
            items={ [
              {
                region: 'content',
                maxWidth: '600px',
                component: (
                  <div style={ { display: 'flex', flexDirection: 'column', gap: '16px' } }>
                    <Panel
                      theme="card-with-highlight"
                      title="Project Details"
                    >
                      <Form.Item
                        label="Project Name"
                        name="projectName"
                      >
                        <Input placeholder="Enter project name" />
                      </Form.Item>

                      <Form.Item
                        label="Description"
                        name="description"
                      >
                        <TextArea
                          placeholder="Describe your project..."
                          rows={ 4 }
                        />
                      </Form.Item>

                      <Form.Item
                        label="Budget"
                        name="budget"
                      >
                        <InputNumber
                          formatter={ (value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',') }
                          parser={ (value) => value?.replace(/\$\s?|(,*)/g, '') ?? '' }
                          placeholder="Enter budget"
                          style={ { width: '100%' } }
                        />
                      </Form.Item>
                    </Panel>

                    <Panel
                      theme="card-with-highlight"
                      title="Timeline"
                    >
                      <div style={ { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' } }>
                        <Form.Item
                          label="Start Date"
                          name="startDate"
                        >
                          <Input placeholder="Select start date" />
                        </Form.Item>

                        <Form.Item
                          label="End Date"
                          name="endDate"
                        >
                          <Input placeholder="Select end date" />
                        </Form.Item>
                      </div>

                      <Form.Item
                        label="Priority"
                        name="priority"
                      >
                        <Select
                          options={ [
                            { value: 'low', label: 'Low' },
                            { value: 'medium', label: 'Medium' },
                            { value: 'high', label: 'High' },
                            { value: 'urgent', label: 'Urgent' }
                          ] }
                          placeholder="Select priority"
                        />
                      </Form.Item>
                    </Panel>
                  </div>
                )
              },
              {
                region: 'sidebar',
                maxWidth: '300px',
                component: (
                  <div style={ { display: 'flex', flexDirection: 'column', gap: '16px' } }>
                    <Panel
                      border
                      theme="fieldset"
                      title="Settings"
                    >
                      <Form.Item
                        label="Public Project"
                        name="isPublic"
                        valuePropName="checked"
                      >
                        <Switch />
                      </Form.Item>

                      <Form.Item
                        label="Allow Comments"
                        name="allowComments"
                        valuePropName="checked"
                      >
                        <Switch />
                      </Form.Item>

                      <Form.Item
                        label="Send Updates"
                        name="sendUpdates"
                        valuePropName="checked"
                      >
                        <Switch />
                      </Form.Item>
                    </Panel>

                    <Panel
                      border
                      collapsed
                      collapsible
                      theme="fieldset"
                      title="Team"
                    >
                      <Form.Item
                        label="Team Lead"
                        name="teamLead"
                      >
                        <Select
                          options={ [
                            { value: 'john', label: 'John Doe' },
                            { value: 'jane', label: 'Jane Smith' },
                            { value: 'bob', label: 'Bob Johnson' }
                          ] }
                          placeholder="Select team lead"
                        />
                      </Form.Item>

                      <Form.Item
                        label="Team Size"
                        name="teamSize"
                      >
                        <InputNumber
                          max={ 50 }
                          min={ 1 }
                          placeholder="5"
                          style={ { width: '100%' } }
                        />
                      </Form.Item>
                    </Panel>
                  </div>
                )
              }
            ] }
            layoutDefinition={ [
              'content sidebar'
            ] }
          />

          <div style={ { marginTop: '24px' } }>
            <Button
              htmlType="submit"
              type="primary"
            >
              Create Project
            </Button>
          </div>
        </FormKit>
      </div>
    </FormLayoutContainer>
  )
}

export const SidebarForm: Story = {
  render: () => <SidebarFormComponent />
}
