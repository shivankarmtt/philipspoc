/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { createStyles } from 'antd-style'

export const useStyle = createStyles(({ token, css }) => {
  return {
    hotspotImage: css`
            position: relative;
            width: fit-content;
            height: auto;
            margin: 0 auto;
            
            .hotspot-image__image {
                width: auto;
                max-width: 100%;
                height: auto;
                display: block;
            }
            
            .hotspot-image__item {
                border-radius: ${token.borderRadius}px;
                color: ${token.colorPrimary};
                background: ${token.colorFillAlter};
                border: 3px dashed ${token.colorPrimaryBorder};
                border-radius: ${token.borderRadius}px;
                user-select: none;
                cursor: nwse-resize;
                
                &:before {
                    content: '';
                    position: absolute;
                    right: 6px;
                    bottom: 6px;
                    left: 6px;
                    top: 6px;
                    cursor: move;
                }
            }
            
            .hotspot-image__item--marker {
                cursor: move;
                border-width: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                background: transparent;
            }

            .hotspot-image__item--disabled {
                cursor: default;
                &:before {
                    cursor: default;
                }
            }
            
            .hotspot-image__popover {
            }
        `,
    Popover: css`
            .ant-popover-inner {
                padding: ${token.paddingXS}px;
            }
        `
  }
})
