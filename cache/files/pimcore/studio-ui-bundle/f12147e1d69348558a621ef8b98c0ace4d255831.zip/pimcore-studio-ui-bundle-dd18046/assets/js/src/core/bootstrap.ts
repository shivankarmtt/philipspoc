/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import 'reflect-metadata'
import '@Pimcore/app/config/app-config'
import '@Pimcore/app/module-system/module-system'
import '@Pimcore/app/config/services'
import '@Pimcore/modules/background-processor'
import '@Pimcore/app/i18n'
import '@Pimcore/modules/app/base-layout'
import '@Pimcore/modules/app/base-layout/main-nav'
import '@Pimcore/modules/icon-library'
import '@Pimcore/modules/asset'
import '@Pimcore/modules/notifications'
import '@Pimcore/modules/data-object'
import '@Pimcore/modules/document'
import '@Pimcore/modules/element'
import '@Pimcore/modules/execution-engine'
import '@Pimcore/modules/element/dynamic-types'
import '@Pimcore/modules/app/theme/dynamic-types'
import '@Pimcore/modules/wysiwyg'
import '@Pimcore/modules/perspective-editor'
import '@Pimcore/modules/widget-editor'
import '@Pimcore/modules/widget-manager'
import 'flexlayout-react/style/light.css'
import '../../../css/globals.css'
import '@Pimcore/modules/email'
import '@Pimcore/modules/recycle-bin'
import '@Pimcore/modules/open-element'
import '@Pimcore/modules/notes-and-events'
import '@Pimcore/modules/predefined-properties'
import '@Pimcore/modules/tags'
import '@Pimcore/modules/redirects'
import '@Pimcore/modules/document-types'
import '@Pimcore/modules/website-settings'
import '@Pimcore/modules/translations'
import '@Pimcore/modules/reports'
import '@Pimcore/modules/application-logger'
import '@Pimcore/modules/user'
import '@Pimcore/components/icon-selector'
import '@Pimcore/modules/about'
import '@Pimcore/modules/class-definition'
import '@Pimcore/modules/field-definitions'
