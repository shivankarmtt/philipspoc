/**
 * This source file is available under the terms of the
 * Pimcore Open Core License (POCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (https://www.pimcore.com)
 *  @license    Pimcore Open Core License (POCL)
 */

import { type NamePath } from 'antd/es/form/interface'
import React, { createContext, useMemo } from 'react'
import { useFormGroupOptional } from './use-form-group-optional'
import { isArray } from 'lodash'

export interface FormGroupData {
  name: NamePath
}

export type FormGroupContextProps = FormGroupData | undefined

export const FormGroupContext = createContext<FormGroupContextProps>(undefined)

export interface FormGroupProviderProps {
  name: FormGroupData['name']
  children: React.ReactNode
}

export const FormGroupProvider = ({ name, children }: FormGroupProviderProps): React.JSX.Element => {
  const groupContext = useFormGroupOptional()

  const groupName = useMemo(() => {
    if (groupContext !== undefined) {
      const { name: parentName } = groupContext
      return [
        ...(isArray(parentName) ? parentName : [parentName]),
        ...(isArray(name) ? name : [name])
      ]
    }
    return name
  }, [groupContext, name])

  const contextValue = useMemo(() => ({ name: groupName }), [groupName])

  return (
    <FormGroupContext.Provider value={ contextValue }>
      {children}
    </FormGroupContext.Provider>
  )
}
