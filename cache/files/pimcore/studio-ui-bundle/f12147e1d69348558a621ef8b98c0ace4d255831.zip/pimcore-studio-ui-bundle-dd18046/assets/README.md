# Studio UI

This package serves as the foundational user interface layer for Pimcore Studio, offering key resources and integration tools to support frontend development within the Pimcore ecosystem.

It includes:

- Comprehensive TypeScript definitions for the SDK, ensuring strong typing and improved developer experience
- A dedicated plugin that defines entry points for rsbuild, streamlining the build process and project structure

## Documentation

For detailed guidance on installation, plugin development, configuration, and core concepts, refer to the official [Pimcore Studio UI documentation](https://docs.pimcore.com/platform/next/Studio_UI/). It provides in-depth examples and best practices to help you get started and make the most of this package.
